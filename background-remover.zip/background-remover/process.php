<?php

function processSignature($inputPath, $outputPath)
{


    if(!extension_loaded('gd')){

        throw new Exception(
            "GD library is not available."
        );

    }



    // Detect image type

    $info = getimagesize($inputPath);


    if(!$info){

        throw new Exception(
            "Invalid image file."
        );

    }



    switch($info['mime']){


        case 'image/jpeg':

            $image = imagecreatefromjpeg($inputPath);

        break;


        case 'image/png':

            $image = imagecreatefrompng($inputPath);

        break;


        case 'image/webp':

            $image = imagecreatefromwebp($inputPath);

        break;


        default:

            throw new Exception(
                "Unsupported image format."
            );

    }



    $width  = imagesx($image);
    $height = imagesy($image);



    // Create transparent canvas

    $output = imagecreatetruecolor(
        $width,
        $height
    );


    imagealphablending(
        $output,
        false
    );


    imagesavealpha(
        $output,
        true
    );


    $transparent = imagecolorallocatealpha(
        $output,
        255,
        255,
        255,
        127
    );


    imagefill(
        $output,
        0,
        0,
        $transparent
    );




    for($y=0; $y<$height; $y++){


        for($x=0; $x<$width; $x++){


            $pixel = imagecolorat(
                $image,
                $x,
                $y
            );


            $colors = imagecolorsforindex(
                $image,
                $pixel
            );


            $r = $colors['red'];
            $g = $colors['green'];
            $b = $colors['blue'];



            /*
              Calculate brightness.
              White paper = high brightness
              Ink = low brightness
            */

            $brightness =
                ($r + $g + $b) / 3;



            /*
              Convert brightness to transparency.

              Bright pixels:
              disappear.

              Dark pixels:
              remain.
            */


            if($brightness > 245){


                $alpha = 127;


            }elseif($brightness < 80){


                $alpha = 0;


            }else{


                // preserve gray strokes

                $alpha =
                    intval(
                        ($brightness - 80)
                        /
                        (245 - 80)
                        *
                        127
                    );


            }




            $color = imagecolorallocatealpha(
                $output,
                $r,
                $g,
                $b,
                $alpha
            );



            imagesetpixel(
                $output,
                $x,
                $y,
                $color
            );


        }

    }




    imagepng(
        $output,
        $outputPath
    );


    imagedestroy($image);

    imagedestroy($output);



    return true;

}



