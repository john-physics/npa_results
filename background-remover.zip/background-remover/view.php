<?php

require $_SERVER["DOCUMENT_ROOT"].'/start_session.php';

$BASE_ROUTE = "/background-remover";

if(!isset($_GET['folder'])){


    header(
        "Location:"
        .$BASE_ROUTE
        ."?message="
        .urlencode(
            "No folder selected."
        )
    );

    exit;

}



$folderName =
    basename(
        $_GET['folder']
    );



$folderPath =
    "uploads/"
    .$folderName;



if(
    !is_dir($folderPath)
){


    header(
        "Location:"
        .$BASE_ROUTE
        ."?message="
        .urlencode(
            "Folder does not exist."
        )
    );

    exit;

}



$images = glob(
    $folderPath."/*.png"
);



if(!$images){

    header(
        "Location:"
        .$BASE_ROUTE
        ."?message="
        .urlencode(
            "No processed images found."
        )
    );

    exit;

}

sort($images);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Processed Signatures</title>

<style>

*{
    box-sizing:border-box;
}


body{

    margin:0;

    font-family:
    Arial,
    Helvetica,
    sans-serif;

    background:#f4f6f9;

    color:#222;

}



.container{

    max-width:1100px;

    margin:auto;

    padding:30px 20px;

}



.header{

    background:white;

    border-radius:16px;

    padding:25px;

    margin-bottom:25px;

    box-shadow:
    0 10px 30px rgba(0,0,0,.08);

}



.header h1{

    margin:0 0 10px;

    font-size:28px;

}



.folder-name{

    color:#666;

    font-size:14px;

}



.actions{

    margin-top:20px;

}



.btn{

    display:inline-block;

    padding:12px 20px;

    border-radius:10px;

    text-decoration:none;

    background:#5b1028;

    color:white;

    transition:.3s;

}



.btn:hover{

    opacity:.85;

}





.gallery{

    display:grid;

    grid-template-columns:
    repeat(
        auto-fit,
        minmax(250px,1fr)
    );

    gap:20px;

}





.card{

    background:white;

    border-radius:16px;

    padding:20px;

    box-shadow:
    0 8px 25px rgba(0,0,0,.08);

}



.card img{

    width:100%;

    height:220px;

    object-fit:contain;

    background:
    repeating-conic-gradient(
        #eee 0% 25%,
        #fff 0% 50%
    )
    50% /
    20px 20px;

    border-radius:10px;

}



.filename{

    margin-top:15px;

    font-size:14px;

    color:#555;

    word-break:break-all;

}



</style>


</head>


<body>


<div class="container">


<div class="header">


<h1>
Processed Signatures
</h1>


<div class="folder-name">

Folder:
<?=htmlspecialchars($folderName)?>

<br>

<?=count($images)?> processed signature(s)

</div>



<div class="actions">


<a class="btn"
href="/background-remover/download?folder=<?=urlencode($folderName)?>">

Download ZIP

</a>


</div>


</div>





<div class="gallery">


<?php foreach($images as $image): ?>


<div class="card">


<img src="/background-remover/<?=htmlspecialchars($image)?>">


<div class="filename">

<?=htmlspecialchars(basename($image))?>

</div>


</div>



<?php endforeach; ?>


</div>



</div>


</body>

</html>