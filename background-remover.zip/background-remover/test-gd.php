<?php

//phpinfo();


//die();

echo "<pre>";

echo "extension_dir: ".ini_get('extension_dir')."\n\n";

$ext = ini_get('extension_dir').'/gd.so';

echo "Checking: ".$ext."\n";

var_dump(file_exists($ext));





echo "<pre>";

echo "extension_dir = ".ini_get('extension_dir')."\n\n";

echo "gd extension loaded: ";
var_dump(extension_loaded('gd'));

echo "\n";

if(file_exists(ini_get('extension_dir').'/gd.so')){
    echo "gd.so EXISTS\n";
}else{
    echo "gd.so NOT FOUND\n";
}