<?php

function head($meta,$title,$dashb=null){

 global $siteName,$conn;

   
 echo '<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name ="description" content="'.$meta.'">
<meta name ="key words" content="NewPhase, Academy,Result,Check result,ABC">
<meta name="author" content="John Ella">
 
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<link rel="stylesheet" href="./css/new_styles.css">
<link rel="stylesheet" href="./css/styles.css">
 <link rel="stylesheet" href="./css/form_styles.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
   
  <style>
.section h2{
  
  color: rgb(50,200,150); 
  text-decoration:none;    
    
}
 hr{
       
    border: 1px solid hsl(60,50%,50%);   
       
   }
   
    .section #day{
    position:absolute:
    top:100px;
     display:block;
     text-align:center;
     font-size:12px;
     color: rgb(50,200,150); 
   margin-bottom:10px;
 }
  
   .section #warning{
 display:flex;
  justify-content:center;
 align-items:center;
     color:hsl(0,40%,60%);
     font-size:30px;
     margin-bottom:10px;
   
 } 
 .section #no-data{
 font-size:12px;   
   position:relative;
   top:-5px;
   color:rgb(150,200,250);
}
  .bounce {
  animation: bounce 2s infinite;
}

@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
}


.nav-bar{
    position:absolute;
    right:0;

    display: inline-flex;
    flex-direction:row; 
    justify-content:center;
    align-items:center;
    width:80%;
    gap: 10%;
  font-size:19px;
  overflow-x:scroll;
  -ms-overflow-style: none;/* IE & Edge */
  scrollbar-width: none;  /* Firefox */
 
 }

.nav-bar span{
    cursor:pointer;
    transition:0.3s ease;
    
}

.nav-bar a{
    text-decoration:none;
}
    

.nav-bar::-webkit-scrollbar {
  display: none;
}

.nav-bar #kuchy-logo{
  position:relative;  
  top: 5px;
  width: 22px;
  height:22px;
  border-radius:50%;
    
}


.nav-bar #notify-badge {
  position: absolute;
  top: 0;
  left:16%;
  background: #dc3545; /* red */
  color: white;
  font-size: 8px;
  font-weight: bold;
  padding: 1px 5px;
  border-radius: 50%;
} 
  
.nav-bar #client-badge {
  position: absolute;
  top: 0;
  left: 33%;
  background: #dc3545; /* red */
  color: white;
  font-size: 8px;
  font-weight: bold;
  padding: 1px 5px;
  border-radius: 50%;
} 
  
  .nav-bar #fees-badge {
  position: absolute;
  top: 0;
  left: 49.5%;
  background: #dc3545; /* red */
  color: white;
  font-size: 8px;
  font-weight: bold;
  padding: 1px 5px;
  border-radius: 50%;
} 
  
  
  .nav-bar #star-badge {
  position: absolute;
  top: 0;
  left: 66%;
  background: #dc3545; /* red */
  color: white;
  font-size: 8px;
  font-weight: bold;
  padding: 1px 5px;
  border-radius: 50%;
} 
   
 
 .nav-bar #kuchy-badge {
  position: absolute;
  top: 0;
  left: 84%;
  background: rgb(10,250,50); /* red */
  color: white;
  font-size: 8px;
  font-weight: bold;
  padding: 1px 5px;
  border-radius: 50%;
} 
  

#nav-links li {
    text-align: left;
    
}
 #nav-links a{
 font-size:18px;
 
 }
   li i{
    font-size:18px;
    width:1.5rem;
    text-align:center;
    opacity:.95;
    color:#fff;
    margin-right:10px;
  }
 
  .fa-whatsapp{ color:#25D366; } 
  .fa-certificate{ color:gold; }
  .fa-home{ color:#0d6efd;}
  .fa-user-shield{ color:#6f42c1;}
  .fa-globe{ color:#0dcaf0;}
  .fa-gear{ color:#198754;}
  .fa-file-arrow-up { color: #20c997};
  .fa-clapperboard { color: #dc3545; } 
  .fa-book { color: #6610f2; }  
  .fa-cash-register { color: #fd7e14; } 
  .fa-donate { color: #ffc107; }  
  .fa-lock { color: #6c757d; }  
  .fa-info-circle { color: #17a2b8; }
  .fa-certificate { color: #ffc107; }  
  .fa-code { color: #ddd; }  
  .fa-sign-in-alt { color: #0d6efd; } 
  .fa-sign-out-alt { color: #dc3545; }
  .fa-user-graduate { color: #20c997; } 
  .fa-gavel { color: #fd7e14; } 
  .fa-shield-halved { color: #6c757d; } 
  .fa-envelope{ color:#20c997;}
  .fa-bell{ color:#ffc107;} /*yellow bell*/
  /* .fa-briefcase{ color:#0d6efd;} */
  /* .fa-briefcase{ color:#495057;} */
   .fa-briefcase{ color:#20c997;} 
  .fa-sack-dollar { color: #ffc107; }  
  .fa-star{ color:#ffc107;}
  
  #fa-donate{
      
   color:#fd7e14;  
      
  }
#about p {
   text-align: justify; 
    
}
/* Contact Section with Icons */
.contact-item h3 {
    font-size: 1.5rem;
    color: #333;
    margin-bottom: 10px;
    display: flex;
    align-items: center; /* Align text and icon */
    gap: 10px; 
}

.contact-item h3 i {
    color: #00ccff;
    font-size: 1.5rem;
}

/* Add hover effect for icons */
.contact-item h3:hover i {
    color: #333;
}
.contact-form Select{
    background-color: #fff;
}
.report {
            display: none; /* Initially hidden */
            width: 80%;
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            border-radius: 5px;
            font-size: 16px;
            z-index: 1000;
            opacity: 1;
            transition: opacity 2s ease-out;
        }
 #start_btn {
     display: block;
     width: 60%;
     text-align: center;
     text-decoration:none;
     background: rgb(200,100,100);
     color: white;
     border-radius: 10px;
     padding: 10px;
 }
 #survey_progress{
     position: relative;
     bottom: 20px; 
 }
 #skip_btn {
 position: relative;  bottom: 20px; left: 75%; 
 text-decoration: none;
     
     
 }

 
 header{
   position: relative;  
  background: #0077cc;   
     color:#fff;
     text-align: center;
     height: 270px;
 }
 
  header .profile-pic {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    border: 3px dashed  rgb(250,100,250);
    margin-bottom: 5px;
     background:#ff8;
     position:relative;
     top:-20px;
   
}
 header h1{
     position: relative;
     top:-30px;
     font-size: 27px;
     padding: 5px;
 }
 header p{
     position: relative;
     top: -45px;
     font-size: 18px;
     font-style: italic;
     
 }


.new_success{
 top:10px;
 text-align: justify; 
 padding:10px;
 font-size:12px;
 border: 1px solid #fff;
 border-radius:10px;
 background:#007BFF;
 color:white;
 display:block;
 left:10%;
 width:100%;

}
.new_errors{
 top:10px;
 text-align: justify; 
 padding:10px;
 font-size:12px;
 border: 1px solid #fff;
 border-radius:10px;
 background:red;
 color:white;
 display:block;
 left:10%;
 width:100%;

}
  .link_btn {
    text-decoration:none;
    color:white;
    padding:3px;
    border-radius:2px;
    cursor:pointer;
    font-size:12px;
    font-weight:bold;
    display:block;
        width:60px;
        text-align:center;
    }
      #remove_link_btn{
    
    background:rgba(250,50,50,0.5);
    
    }
     #view_link_btn{
    
    background:rgba(10,100,250,0.5);
    
    } 
      #dwn_link_btn{
    
    background:rgba(150,100,150,0.5);
    
    } 
      #grade_link_btn{
    
    background:rgba(10,200,150,0.5);
    
    } 
    
    .contact-form #label{
        position:relative;
        top:10px;
        font-style:italic;
    }
    

</style>
    
</head>
<body>

<script>
window.safeExit = false;
</script>

 <!-- Header Section -->
 <header>
 <div class="container">';

$prfDir = "/images/npa-logo.jpg";
if($dashb == "profile" && isset($_SESSION["staff_id"])){
 
 $staff_id = $_SESSION["staff_id"];
 $det = collect_table_data1($conn,"staffs","staff_id",$staff_id,"i","","profile",1);  
   
 if($det && is_array($det)){
 $profile = null_check($det[0],"null.jpg");
 $prf = "/images/staff/$profile";
 $prfPath = $_SERVER["DOCUMENT_ROOT"].$prf;
  
  if(file_exists($prfPath)){
     
    $prfDir = "/images/staff/$profile";
   
  }
 }
}

 echo '<a href="'.$prfDir.'"><img src="'.$prfDir.'" alt="Logo" class="profile-pic" id="profile-pic"></a>
            <h1>'.$siteName.'</h1>
            <p>Result Portal</p>
        </div>
    </header>';  
    
    
}
?>
