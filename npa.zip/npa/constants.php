<?php

// constants
$root = $_SERVER["DOCUMENT_ROOT"];
// $config is already loaded in dbcon, just extract constants directly. 
$rurl = $config["data"]["rurl"];
$hurl = $config["data"]["hurl"];
$dirgen =$config["data"]["dirgen"];
$manager = $config["data"]["manager"];
$ictdir =$config["data"]["ictdir"];
$asstictdir = $config["data"]["asstictdir"];
$principal =$config["data"]["principal"];
$exam_officer = $config["data"]["exam_officer"];
$asst_exam_officer = $config["data"]["asst_exam_officer"];
$site = $config["data"]["site"];
$site2 = $config["data"]["site2"];
$siteEmail = $config["data"]["siteEmail"];
$schoolAddress = $config["data"]["schoolAddress"];
$siteName = $site;
$authorized =[$dirgen,$manager,$ictdir,$principal,$asstictdir,$exam_officer,$asst_exam_officer];
$appointers = [$dirgen,$principal,$manager];
$staffCats = collect_table_data($conn,"staffs","","staff_cat");

$naira = "₦";
$dollar = "💲";
$dollarsack ="💰";

