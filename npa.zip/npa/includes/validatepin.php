<?php
if($_SERVER["REQUEST_METHOD"] =="POST"){
 
  $root = $_SERVER["DOCUMENT_ROOT"];
 require $root.'/page_init.php';

 $btn = trim($_POST["submit_button_name"]);
 $pin = trim($_POST["std_pin"]);
// sleep(2);
if($btn == "check_pin"){
 
 if(!$pin){
  
    $response = [
      
     "status" => "failed",
     "error" => "Empty Input",
     "message" =>"Please enter your PIN",
     "pin" => "unverified"
      ]; 
    
  echo json_encode($response);
exit();      
     
     
 } 
 elseif(!preg_match('/^[A-Za-z0-9]{8}$|^[A-Za-z0-9]{10}$/', $pin)) {
   
    $response = [
      
     "status" => "failed",
     "error" => "Pin format",
     "message" =>"Invalid PIN format",
     "pin" => "unverified"
      ]; 
    
  echo json_encode($response);
exit();          
     
 }
 elseif(check_exist($conn,"students","std_pin",$pin,"s")){
     
     $response = [
     "status" => "success",
     "error" => "None",
     "message" =>"PIN verified",
     "pin" => "valid"
      ]; 
    
  echo json_encode($response);
exit(); 

 }
  else{
    
     $response = [
     "status" => "failed",
     "error" => "Validility",
     "message" =>"Invalid PIN",
     "pin" => "invalid"
      ]; 
    
  echo json_encode($response);
exit();      
      
  }  
}
else{
    
  $response = [
      
     "status" => "failed",
     "error" => "Button Name",
     "message" =>"Unrecognized button name",
     "pin" => "unverified"
      ]; 
    
  echo json_encode($response);
exit();   
      
 }
}
else{
    
  $response = [
     "status" => "failed",
     "error" => "REQUEST_METHOD",
     "message" => "Unknown Request method",
      ];
echo json_encode($response);
exit();   
    
    
}