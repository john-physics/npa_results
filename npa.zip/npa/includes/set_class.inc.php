<?php

if($_SERVER["REQUEST_METHOD"] =="POST"){
 
 require  $_SERVER["DOCUMENT_ROOT"].'/page_init.php';

  $data = json_decode(file_get_contents('php://input'), true);
  $btn = trim($data["button_name"]); 

if(isset($_SESSION["staff_id"])){
    
 $userId= $_SESSION["staff_id"];
 $userCat = $_SESSION["staff_cat"];
}
else{
    
     $response = [
     "status" => "failed",
     "error" => "user_login",
     "message" => "Please login to continue !",
      ];
echo json_encode($response);
exit();      
     
 }
 
 if($btn == "load_students"){
   
  $class = trim($data["class_name"]);
 
 $stutdents = fetch_students($conn,$class);
 
 /* the function above first load students in the passed class and related atms
  then load Students in nearby classes (1 class behind and after)
  */ 
        
      $response = [
     "status" => "success",
     "error" => "none",
     "message" => "Students loaded successfully ✓",
     "students" => $stutdents,
      ];
      
echo json_encode($response);
exit();
     
 }
 
 elseif($btn == "save_students"){
 
  $class = trim($data["class_name"]);
  $term_session = trim($data["term_session"]);
  $students = $data["students"]??[];
  $staff_id = trim($data["staff_id"]);
  
   if(!$staff_id){
       
       $response = [
     "status" => "failed",
     "error" => "user_login",
     "message" => "Please login to continue !",
      ];
echo json_encode($response);
exit();     
       
   }
   
   elseif(!$students){
       
       $response = [
     "status" => "failed",
     "error" => "select_error",
     "message" => "Please select atleast 1 student!",
      ];
echo json_encode($response);
exit();    
       
   }
   else{
     
  $explode = explode(" ",$term_session);
  $term = $explode[0]." ".$explode[1];
  $session = $explode[2];
  $ImpStds = implode(":",$students);
    
   if(check_exist4($conn,"class_set","staff_id","session","term","class",$staff_id,$session,$term,$class,"isss")){
  //update records
  
 if(update_user_data4($conn,"class_set","students","staff_id","session","term","class",$ImpStds,$staff_id,$session,$term,$class,"sisss")){
     
  update_user_data4($conn,"class_set","date_created","staff_id","session","term","class",$DayDateTime,$staff_id,$session,$term,$class,"sisss");
  
 update_stds_class($conn,$students,$class);
  
      $response = [
     "status" => "success",
     "error" => "None",
     "message" => "$class students updated successfully",
      ];
echo json_encode($response);
exit(); 
  
     
 }
 else{
     
     $response = [
     "status" => "failed",
     "error" => "sql_error",
     "message" => "Unable to update $class students, Please try again.",
      ];
echo json_encode($response);
exit();   
     
     }
   }
   else{
  //new records     
       
  $insertData =[
     "conn" => $conn,
     "table" => "class_set",
     "cols" => ['staff_id','session','term','class','students','date_created'],
     
     "vals"=> [$staff_id,$session,$term,$class,$ImpStds,$DayDateTime],
     "params" => "isssss"
      
      ];
  
 $insert = insert_user_data($insertData);
 
 if($insert["status"] =="success"){
  
 update_stds_class($conn,$students,$class);
 
      $response = [
     "status" => "success",
     "error" => "None",
     "message" => "$class students added successfully",
      ];
echo json_encode($response);
exit();    
    
     
 }
 else{
     
    
     $response = [
     "status" => "failed",
     "error" => "sql_error",
     "message" => "Unable to add students to $class, Please try again.",
      ];
echo json_encode($response);
exit();    
     
     
     }
    }
   }
 }
 
  elseif($btn == "save_subjects"){
 
  $class = trim($data["class_name"]);
  $term_session = trim($data["term_session"]);
  $subjects = $data["subjects"]??[];
  $staff_id = trim($data["staff_id"]);
  
   if(!$staff_id){
       
       $response = [
     "status" => "failed",
     "error" => "user_login",
     "message" => "Please login to continue !",
      ];
echo json_encode($response);
exit();     
       
   }
   
   elseif(!$subjects){
       
       $response = [
     "status" => "failed",
     "error" => "select_error",
     "message" => "Please select atleast 1 subject!",
      ];
echo json_encode($response);
exit();    
       
   }
   else{
     
  $explode = explode(" ",$term_session);
  $term = $explode[0]." ".$explode[1];
  $session = $explode[2];
  $ImpSubjects = implode(":",$subjects);
    
   if(check_exist4($conn,"class_set","staff_id","session","term","class",$staff_id,$session,$term,$class,"isss")){
  //update records
  
 if(update_user_data4($conn,"class_set","subjects","staff_id","session","term","class",$ImpSubjects,$staff_id,$session,$term,$class,"sisss")){
     
  update_user_data4($conn,"class_set","date_created","staff_id","session","term","class",$DayDateTime,$staff_id,$session,$term,$class,"sisss");
  
      $response = [
     "status" => "success",
     "error" => "None",
     "message" => "$class subjects updated successfully",
      ];
echo json_encode($response);
exit(); 
  
     
 }
 else{
     
     $response = [
     "status" => "failed",
     "error" => "sql_error",
     "message" => "Unable to update $class subjects, Please try again.",
      ];
echo json_encode($response);
exit();   
     
     }
   }
   else{
  //new records     
       
  $insertData =[
     "conn" => $conn,
     "table" => "class_set",
     "cols" => ['staff_id','session','term','class','subjects','date_created'],
     
    "vals"=> [$staff_id,$session,$term,$class,$ImpSubjects,$DayDateTime],
     "params" => "isssss"
      
      ];
  
 $insert = insert_user_data($insertData);
 
 if($insert["status"] =="success"){
  
      $response = [
     "status" => "success",
     "error" => "None",
     "message" => "$class subjects added successfully",
      ];
echo json_encode($response);
exit();    
    
     
 }
 else{
     
    
     $response = [
     "status" => "failed",
     "error" => "sql_error",
     "message" => "Unable to add $class subjects, Please try again.",
      ];
echo json_encode($response);
exit();    
     
     
     }
    }
   }
 }
 
 elseif($btn == "load_subjects"){
  
$subjects =[];  
$subjs = collect_table_data1($conn,"variables","type","Subject","s","value ASC");

foreach ($subjs as $subj){
    
   $sub = [
       "id" => $subj["id"],
       "name" => $subj["value"],
       
       ];
       
  $subjects[] = $sub;     
      
}

    $response = [
     "status" => "success",
     "error" => "none",
     "message" => "Subjects loaded successfully ✓",
     "subjects" => $subjects,
      ];
      
echo json_encode($response);
exit();


 }
 
 
 //more btns here.
 else{
     
    $response = [
     "status" => "failed",
     "error" => "button_name",
     "message" => "Unrecognized button name !",
      ];
echo json_encode($response);
exit();   
     
  }
 }
else{
    
  $response = [
     "status" => "failed",
     "error" => "REQUEST_METHOD",
     "message" => "Unauthorized request method !",
      ];
echo json_encode($response);
exit();      
     
    
}