<?php

function update_stds_class($conn,$students,$class){
 
 
 //get class cat 
  $classVar = collect_user_data2($conn,"variables","type","value","Class",$class,"ss");
 $classCat = $classVar["classification"];
   
   if(is_array($students)){
   //$students is an array of std Ids  
   foreach ($students as $std){
    update_user_data($conn,"students","current_class","std_id",$class,$std,"si"); 
    
     update_user_data($conn,"students","std_cat","std_id",$classCat,$std,"si");  
   }
       
    return true;    
   }
   else{
    //single std id
  if(update_user_data($conn,"students","current_class","std_id",$class,$students,"si")){
     
     update_user_data($conn,"students","std_cat","std_id",$classCat,$students,"si");  
    
     return true;
     }  
   }
    
 return false;   
}
 

function log_errors($errorname,$request,$error){
    
 $errorfile = $errorname.".log";
 $errorSavePath = $_SERVER["DOCUMENT_ROOT"] . "/logs";

if(!is_dir($errorSavePath)){

   mkdir($errorSavePath, 0755, true);
}

$logFile = $errorSavePath."/".$errorfile;

$logMessage = "

[" . date("Y-m-d h:i:s A") . "]

ERROR Name: ".strtoupper($errorname)."

REQUEST: $request

ERROR DESCRIPTION: $error

==================================================

";

if(file_put_contents($logFile,$logMessage, FILE_APPEND)){
    
    return true;
} 
    
  else{
      return false;
  }  
}


function staff_titles(){
  
  $titles = ['Mr.','Mrs.','Miss.','Dr.','Prof.','Pst.','Fr.','Rev.','Rev. Dr.','Rev. Fr.','Dr. Mrs.','Dr. Miss.','Prof. Mrs.','Prof. Miss.','Pst. Mrs.','Pst. Dr.'];
    
 
return $titles;

}


function get_class_dets($type,$value){
global $conn;


if($type == "class"){
 
    
 //code class' teacher later. 
 $current =  get_current_session(); 
 $term = $current["term"];
 $session = $current["session"];
 
 $stdNum = count_user_data($conn,"students","current_class",$value,"s");
 $det = collect_user_data2($conn,"variables","type","value","Class",$value,"ss");

$cat = $det["classification"];
$assPattern = $det["assessment_pattern"];
 
 
 
 $classDets = [
     "teacher"=>"Unknown",
     "std_num"=>$stdNum,
     "class_cat" => $cat,
     "ass_pattern" => $assPattern,
     "term" => $term,
     "session" => $session
     ];
    
 
  return $classDets;    
    
}

elseif($type == "subject"){
    
  $det = collect_user_data2($conn,"variables","type","value","Subject",$value,"ss");
  $cat = $det["classification"];  
 
 
 $subjDets = [
     "teacher"=>"Unknown",
     "subj_cat" => $cat,
   
     ];
    
 
  return $subjDets;  
  }
}



function validate_phone_number($phone) {

    // Remove spaces, brackets, hyphens
    $phone = preg_replace('/[\s\-\(\)]/', '', $phone);

    // Remove leading +
    $digits_only = ltrim($phone, '+');

    // Ensure digits only
    if (!ctype_digit($digits_only)) {
        return false;
    }

    // Normalize formats
    if (preg_match('/^0\d{10}$/', $phone)) {
        return true;
    }

    if (preg_match('/^234\d{10}$/', $phone)) {
        return true;
    }

    if (preg_match('/^\+234\d{10}$/', $phone)) {
        return true;
    }

    return false;
}

function inser_into_queue($msg){
   global $conn,$DateTime; 
    
  $name = $msg["name"];
  $email = $msg["email"];
  $msg_subj = $msg["subject"];
  $msg_body = $msg["body"];
  $attach = $msg["attach"]??null;
  
 $EmailData = [
     "conn" => $conn,
     "table" => "mail_queue",
     "cols" => ['recipient_name','recipient_email','subject','message','attachment','created_at'],
     "vals" => [$name,$email,$msg_subj,$msg_body,$attach,$DateTime],
     "params" => 'ssssss'
     ];

$queue = insert_user_data($EmailData);
    
return $queue;
    
}

function std_num($num, $std = 'cc') {

//cc: country Code
//ncc: no country Code
 $clean = preg_replace('/\D/', '', $num);

if ($std === 'cc') {
    
 if (substr($clean, 0, 3) === '234' && strlen($clean) == 13) {
            return $clean;
        }

if (substr($clean, 0, 1) === '0' && strlen($clean) == 11) {
            return '234' . substr($clean, 1);
        }

      
  if (strlen($clean) == 10) {
            return '234' . $clean;
        }

        return null; // invalid number
    }

 
 if ($std === 'ncc') {

  if (substr($clean, 0, 1) === '0' && strlen($clean) == 11) {
            return $clean;
        }

 
  if (substr($clean, 0, 3) === '234' && strlen($clean) == 13) {
            return '0' . substr($clean, 3);
        }


   if (strlen($clean) == 10) {
            return '0' . $clean;
        }

        return null;
    }

    // If $std is unknown
    return null;
}

function get_current_session(){
 global $conn; 
 $current = ["term" =>"","session"=>""];

$session = collect_user_data($conn, "variables","type","Current Session","s");
$term = collect_user_data($conn, "variables","type","Current Term","s");
 
if($session && $term){

$current = [
  "term" => $term["value"],
  "session" => $session["value"],
];

}

return $current;
}

function switch_user($user_cat=null){
 
 global $conn;
  $staffCats = collect_table_data($conn,"staffs","","staff_cat");


 $switch = [
   "conn"  => "",
   "table" => "",
   "id_col" => "",
    "user_id" => "",
    "user_cat" => "" ,
    "user_type" => "",
   ]; 


if($user_cat){
    
 if(in_array($user_cat,$staffCats)){
 
 
 $switch = [
   "conn"  => $conn,
   "table" => "staffs",
   "id_col" => "staff_id",
   "user_id" => "",
   "user_cat" => $user_cat,  
  "user_type" => "Staff",
   "prf_dir" => "/images/staff"
 
     ];
} 
 else{
 
 $switch = [
   "conn"  => $conn,
   "table" => "students",
   "id_col" => "std_id",
   "user_id" => "",
    "user_cat" => $user_cat, 
    "user_type" => "Student",
    "prf_dir" => "/images/students"
     ];
 }
}
elseif(isset($_SESSION["staff_id"]) && isset($_SESSION["staff_cat"])){
    
  $user_id = $_SESSION["staff_id"];
  $user_cat = $_SESSION["staff_cat"];

 $switch = [
   "conn"  => $conn,
   "table" => "staffs",
   "id_col" => "staff_id",
     "user_id" => $user_id,
     "user_cat" => $user_cat,
     "user_type" => "Staff",
    "prf_dir" => "/images/staff"
    
     ];

}
elseif(isset($_SESSION["std_id"]) && isset($_SESSION["std_cat"])){
    
$user_id = $_SESSION["std_id"];
$user_cat = $_SESSION["std_cat"];
 $switch = [
   "conn"  => $era_db,
   "table" => "students",
   "id_col" => "std_id",
     "user_id" => $user_id,
     "user_cat" => $user_cat,
     "user_type" => "Student",
    "prf_dir" => "/images/students"

     ];

}


    
 return $switch;   
}

function addBtn($btn,$dir,$id="addbtn"){


 echo '<a class="addbtn" id="'.$id.'" href="'.$dir.'">'.$btn.'</a>
 
 <style>
 .addbtn {
   position:relative;
   top:10px;
   padding:5px;
   border-radius:10px;
    color:white;
    background: rgb(200,50,50);
    cursor:pointer;
    display:flex;
    flex-direction:column;
    align-items:center;
    text-decoration:none;
    margin:20px;
 }
 </style>';
   
}

function addTableBtn($btns){

 echo '<div class="table_btn">';
 
 if(is_array($btns)){
 
  foreach ($btns as $btn){
   $btnName = $btn["btn_name"];
   $btnDir = $btn["btn_dir"];
   $btnId = $btn["btn_id"];
   $att1 = $btn["btn_att1"];
   $att2 = $btn["btn_att2"];
   $attv1 = $btn["btn_attv1"];
   $attv2 = $btn["btn_attv2"];
    
  if(!$btnId){
      $btnId = "view_ass";//default btn Id
  }
  
 if(!$att1){
     $att1 = "data-id";
 }
  
  if(!$att2){
     $att2 = "data-name";
 } 
 
  echo ' <a id="'.$btnId.'" href="'.$btnDir.'" '.$att1.'="'.$attv1.'" '.$att2.'="'.$attv2.'">'.$btnName.'</a>';   
      
  }   
    
 }
 echo '</div>
 
 <style>
   .table_btn{
    
    display:flex;
    flex-direction:horizontal;
    gap:10px;

    }
    
    .table_btn a{
    text-decoration:none;
    color:white;
    padding:8px;
    border-radius:4px;
    cursor:pointer;
    font-size:10px;
    font-weight:bold;
    display:block;
        width:90px;
        text-align:center;
    }
  
   .table_btn #share_cert{
        
     background:rgba(250,50,50,0.5);
      
    }
     .table_btn #remove_ass{
    
    background:rgba(250,50,50,0.5);
    
    }
     .table_btn #view_ass{
    
    background:rgba(10,100,250,0.5);
    
    } 
     .table_btn #dwn_ass{
    
    background:rgba(150,100,150,0.5);
    
    } 
     .table_btn #grade_ass{
    
    background:rgba(10,200,150,0.5);
    
    } 
  

 </style>';
   
}


function Addfooter($site){
    
   $year = date("Y");
 echo '<footer class="footer" id="footer">
     <p>'.$site.' &copy; '.$year.'. All Rights Reserved.</p>
    </footer>';  
    
}

function switch_gender($gender = null, $type = 'pronoun') {
    // Normalize inputs
    $gender = strtolower(trim($gender ?? ''));
    $type   = strtolower(trim($type ?? ''));

    // Define gender-based comparison list
    $comparison = [
        'pronoun'        => ['male' => 'He', 'female' => 'She'],
        'object'         => ['male' => 'Him', 'female' => 'Her'],
        'possessive_adj' => ['male' => 'His', 'female' => 'Her'],    // e.g., his book
        'possessive_pro' => ['male' => 'His', 'female' => 'Hers'],   // e.g., the book is his
        'reflexive'      => ['male' => 'Himself', 'female' => 'Herself'],
        'noun'           => ['male' => 'Man', 'female' => 'Woman'],
        'title'          => ['male' => 'Mr.', 'female' => 'Ms.'],
        'parent'         => ['male' => 'Father', 'female' => 'Mother'],
        'child'          => ['male' => 'Son', 'female' => 'Daughter'],
        'sibling'        => ['male' => 'Brother', 'female' => 'Sister']
    ];

    // If the type exists in the comparison list
    if (isset($comparison[$type])) {
        $maleWord   = $comparison[$type]['male'];
        $femaleWord = $comparison[$type]['female'];

        if ($gender === 'male') {
            return $maleWord;
        } elseif ($gender === 'female') {
            return $femaleWord;
        } else {
            // Gender is null or unspecified
            return $maleWord . '/' . $femaleWord; // e.g., He/She
        }
    }

    // Unknown type
    return null;
}



function show_verify_pay(){
  
 echo '<section id="contact" class="section">
        <h2>Verify Your Payment</h2>
        <form action="/includes/verify.inc" method="POST" class="contact-form" id="RegForm">
    
            <label for="email">Your Email</label>
            <input type="email" id="email" name="email" placeholder="Enter your Email" autofocus required>
            
            <label for="ref">Payment Reference Number</label>
            <input type="text" id="ref" name="ref" placeholder="Enter Payment Reference" required>

            <button type="submit" name="verify_apply_fees">Verify</button>
        </form>
        <div id="spinner"></div>
    </section>
    <script>
  document.getElementById("RegForm").addEventListener("submit",(e)=>{
  
 document.getElementById("spinner").style.display = "flex"; 
  
  });
    
</script>';
    
}


 function pay_Now($era_db,$email,$payment_ref,$course,$service,$vat_rate,$naira,$paystack_pk){
 
$exp = explode("_",$ref);
$index = count($exp)-1;
$str = strtolower($exp[$index]);

if($str == "app"){
 // application fees_payment   
$emailcol = "Applicant's Email";

}
 else{
 // other fees_payment   
$emailcol = "Payer's Email";
     
 }    


 $pay = collect_user_data2($era_db,'Reference','Reference_No','Service',$payment_ref,$service,'ss');  
     
 $amt = $pay['Amount'];
 $vat = round($amt*($vat_rate/100),2);
 $total =  round(($amt + $vat),2);
 $paystack_amt = $total*100; 
 
 echo '<section id="contact" class="section">
    <h2>Confirm Your Details</h2>
 <center>
 <div class="courses-table">
    <table>
    <tr>
    <th>S/N</th>
    <th>'.$emailcol.'</th>
    <th>Payment Reference</th>
    <th>Service Description</th>
    <th>Amount</th>
    <th>Vat & Gateway</th>
     <th>Sub Total</th>
    </tr>';
    
    echo '<tr>
     <td>1.</td>
     <td>'.$email.'</td>
     <td>'.$payment_ref.'</td>
     <td>'.$service.'</td>
     <td>'.$naira. number_format($amt,2).'</td>
    <td>'.$naira. number_format($vat,2).'</td>
    <td>'.$naira. number_format($total,2).'</td>
   </tr>';
          
    echo'</table>
    </div></center>';   
  echo '<p id="total_payable"><small><strong>Total Payable Amount: </strong>'.$naira. number_format($total,2).'</small></p>';  
  echo '<form id="paymentForm" method="post" class="contact-form">

   <input type="hidden" id="payer_email" name="payer_email" value="'.$email.'">
  <input type="hidden" id="reference" name="reference" value="'.$payment_ref.'" >
 <input type="hidden" id="pay_amount" name="amount" value="'.$paystack_amt.'" >
  
  <input type="hidden" id="paystack_pk" name="paystack_pk" value="'.$paystack_pk.'" >
              
 <button type="submit">Pay Now</button>
        </form>
    </section>
<style>
.contact-form button{
    color:white;
    background:rgb(200,50,100);
}
#total_payable{
    display:block;
    position:relative;
    margin-left: 1%;
   
}
@media (min-width: 800px){
    
 #total_payable{
    display:block;
    position:relative;
    margin-left:15%;
   
}   
    
}
</style>';
    
     
 }  

function get_exams_taken($era_db,$std_id,$std_cat){
  //this function check for all Exams taken by a user 
  $examStatus = "Done";
 if(isset($_SESSION["tutor_consent"])){
     $tutor_consent = $_SESSION["tutor_consent"];
     
 }
if(isset($_SESSION["admin_cat"])){
     $admin_cat = $_SESSION["admin_cat"];
     $admin_id = $_SESSION["admin_id"];
 }
 
  
  $AllExams = collect_table_data($era_db,"Exams");
  $exams = [];
  if($AllExams && is_array($AllExams)){
    
  foreach ($AllExams as $exam){
   
   $Id = $exam["Std_ID"];
   $Cat = $exam["Std_Cat"];
   $tutor = $exam["Std_Tutor"];
   $Status = $exam["Exam_Status"];
  
  if($Status == $examStatus){
      
   if($admin_cat == "Default Admin"){
   // return all done  exams for all std
      $exams[] = $exam;     
       
   }
   elseif($tutor_consent == "Yes" && $admin_id == $tutor){
//return all done exams for this tutors stds only 

      $exams[] = $exam;     
     
   }
      
  elseif($Id == $std_id && $Cat == $std_cat){
      
   $exams[] = $exam;   
      
    }  
     
  }
    
   }   
  }
 
 return $exams;
    
}
  
  
 function  calc_learning_progress($era_db,$std_id,$std_cat){
 
 $progress = 0;//initialize progress
 $CoresCat = "Web";//make this dynamic later
 $AvailableCourses = count_user_data($era_db,'Available_Courses','Course_Cat',$CoresCat,'s');
 
 if(check_exist2($era_db,'Exams','Std_ID','Course_Cat',$std_id,$CoresCat,'is')){
 
 $DoneExams = count_user_data3($era_db,'Exams','Std_ID','Course_Cat','Exam_Status',$std_id,$CoresCat,'Done','iss');

 $AvailableExams = count_user_data($era_db,'Fees_Settings','Course_Cat',$CoresCat,'s');
   
$progress = ($DoneExams/$AvailableExams)*100; //in percentage
 $progress = round($progress); 
 
 //check for any course content that has  been done but its exam has not been taken, they will contribute to learning progress but once its exam is taken, we drop them.
 
 $exams = collect_table_data3($era_db,"Exams","Std_ID","Course_Cat","Exam_Status",$std_id,$CoresCat,"Done","iss","DESC","Course");
     
$Cores = collect_table_data3($era_db,"Courses_Done","Std_ID","Course_Cat","Course_Status",$std_id,$CoresCat,"Done","iss","DESC","Course");
 

foreach ($Cores as $core){
  
if(!in_array($core, $exams)){
    
 $Done = count_user_data3($era_db,'Courses_Done','Std_ID','Course','Course_Status',$std_id,$core,'Done','iss'); //count how many courses contents done but not yet taken exam for the course
    
 $percent = ($Done/$AvailableCourses)*100; //in percentage
 $progress+= round($percent); 
  }  
 }
}
 
 else{
     
 $DoneCourses = count_user_data3($era_db,'Courses_Done','Std_ID','Course_Cat','Course_Status',$std_id,$CoresCat,'Done','iss'); //count all done courses based on course cat
 
$progress = ($DoneCourses/$AvailableCourses)*100; //in percentage
 $progress = round($progress); 

  }
  

 if($progress > 100){ 

   $progress = 100;
   
 }
  
   return $progress.'%';
 }
  
 function cal_total_fees($home_db,$era_db,$session){
   
    $paid = collect_table_data($home_db,'Admins');

 //total paid out  
     $total_paid_out= 0; 
     foreach ($paid as $pd){
         $money = $pd["Money"];
         
         $total_paid_out+=$money;
     }
     
// total_paid_fees

  $fees = collect_table_data($era_db,'Fees');
     
     $tut_fees_paid = 0;
     $apply_fees_paid= 0;
  foreach ($fees as $fee) {
      
    $tut_fee_status = $fee["Tuition_Fee_Status"];
     $apply_fee_status = $fee["Apply_Fee_Status"];
    $tuition_fee = $fee["Tuition_Fee_Payable"];
    $apply_fee =$fee["Apply_Fee"];
    
    
   if($tut_fee_status == "Paid"){
       
       $tut_fees_paid+=$tuition_fee;
   }
   
    if($apply_fee_status == "Paid"){
       
       $apply_fees_paid+=$apply_fee;
       
   }  
  }  
  
 
   $total_fees = [
     "paid_apply_fees" => $apply_fees_paid,
     "total_paid_fees" => $tut_fees_paid,
     "total_paid_out" => $total_paid_out,
       ]; 
       
 return $total_fees;    
     
 }

 
 function currently_learning($era_db,$std_id,$std_cat){
     
   $Allcourses = collect_table_data($era_db,'Fees');  
     
  if($Allcourses){
 $courses = [];
 foreach ($Allcourses as $course){
  
  $cores = $course["Course"];
  $Id = $course["Std_ID"];
  $status = $course["Course_Status"];
  $inprogress = "In Progress";
  
  if($Id == $std_id && $status == $inprogress){
      
   $courses[] = $cores;   
      
  }
 }

if($courses){
    
  $count = count($courses);
  $learning = "";
  for($i = 0; $i< $count; $i++){
   $core = $courses[$i];
   $learning = $learning.$core;
   
  if($i < ($count-2)){
     $learning = $learning." , ";  
   }
    elseif($i == ($count-2)){
   $learning = $learning." & ";  
       
   }
  }
 
 return $learning;
 
}
else{
    
  return "No records found"; 
      
  }
      
 }
   
 else{
     
   return "No records found"; 
     
     
  }  
     
 }
 
 function get_fees_status($era_db,$std_id,$std_cat,$learning){

 
if($learning == "No records found"){
        
   return "No Application";     
        
    }
 else{
     
  if(strpos($learning,'&')){
  
 // std is learning more than 1 course 
      
   $exp = explode("&",$learning);
   $str1 = $exp[0];
   $str2 = $exp[1];
   
   if(strpos($str1,",")){
    //str1 still contains more courses, explode them to become array   
    $cores = explode(",",$str1);
       
   }
   else{
   //str1 contains only course, set it as an array   
    $cores = [$str1];  
      
   }
 // bind all courses as one array now. i.e push str2 into the array of courses from str1  
   $cores[] = $str2;
      
  }
  
 else{
 // std is learning only 1 course    
 
 $cores = [$learning];
     
 } 
  
 //now check fees_status 
$feesPaid = [];
 foreach($cores as $core){
 $core = trim($core);
 
 $FeesDet = collect_user_data2($era_db,"Fees","Std_ID","Course",$std_id,$core,"is");
   
   $fees = strtoupper($FeesDet["Tuition_Fee_Status"]);
   
   if($fees === "PAID"){
       $feesPaid[] = $core;
   }
   
 }
 
 
 if(count($cores) == count($feesPaid)){
   
 if(count($cores) == 1){
     
  return  "Paid";   
     
 } 
 
 else{
     
  return "All Fees Paid";    
  }
   
 }
 else{
     
 if(count($cores) == 1){
     
  return  "Not Paid";   
     
 }    
     
  else{
     return  "Not Paid";   
    }   
   }
  
  }  
   
 }
  
  function sub_course_status($era_db,$std_id,$course_code){
      
  $det = collect_user_data2($era_db,"Courses_Done","Std_ID","Course_Code",$std_id,$course_code,"is");
  
  $stat = $det["Course_Status"];
 
 if(!$stat){
     $stat = "In Progress";
 }
 
  return $stat;
      
  }
    
    
function get_tuition_fee_deadline($era_db,$learning,$block){


if($learning == "No records found"){
        
   return null;     
        
    }

else{
    
$std_id = $_SESSION["std_id"];
$std_cat = $_SESSION["std_cat"];
   
 if(strpos($learning,'&')){
  
 // std is learning more than 1 course 
      
   $exp = explode("&",$learning);
   $str1 = $exp[0];
   $str2 = $exp[1];
   
   if(strpos($str1,",")){
 //str1 still contains more courses      
    $cores = explode(",",$str1);
       
   }
   else{
  //there is only 1 course in str1 
    $cores = [$str1];  
      
   }
 // bind all courses as one array now. i.e push str2 into the array of courses from str1   
   
   $cores[] = $str2;
      
  }
  
 else{
 // std is learning only 1 course    
 
 $cores[] = $learning;
     
 }  
  
//check deadlines for each learning cours 
date_default_timezone_set("Africa/Lagos");
$today = date("D d-m-Y");
$todayTotime = strtotime($today); 
 
  foreach ($cores as $core){
  // return if you encounter deadline for any course that needs fees_warning or blocking. 
  
   $core_det = collect_user_data($era_db,"Fees_Settings","Course",$core,"s");  
      
  $deadline = $core_det["Tuition_Fee_Deadline"];
  $Activate_deadline = $core_det["Activate_Deadline"];
  
  
  if($deadline){
 //convert deadline to str
 
 if(strpos($deadline,'/')){
     
 $Deadline = str_replace('/','-',$deadline);
  $DeadlineTotime= strtotime($Deadline);  
 }
 else{
  $DeadlineTotime = strtotime($deadline);      
 }
 
 if($DeadlineTotime >= $todayTotime){
  // deadline was set   
 //block stds that are yet to pay fees 
  //check if std has paid fees & block std if not paid    
  
  $fees = collect_user_data2($era_db,"Fees","Std_ID","Course",$std_id,$core,"is");
 
  $fees_status = $fees["Tuition_Fee_Status"];
  $course_status = $fees["Course_Status"];  
 if($course_status == "In Progress" || $course_status == "Done"){
  
  if($fees_status != "Paid"){
   if($block){
    // std has not paid fees for this Course, block std
   return true;      

   }
     else{
 // return deadline for fees_warning     
   return $deadline;   
      
    }

    }   
   }

  }
 }
  
}
}    
}

function convert_to_array($courses){
 
  if(!is_array($courses)){
 
 //convert courses to an array
 if(strpos($courses,'/')){
 $courses = explode("/",$courses);
 }
 elseif(strpos($courses,'&')){
  $courses = explode("&",$courses);   
 }
  elseif(strpos($courses,',')){
  $courses = explode(",",$courses);   
 }
 
 elseif(strpos($courses,':')){
  $courses = explode(":",$courses);   
 }
 elseif(phrase_contains($courses,'and')){
  $courses = explode("and",$courses);   
 }
 
 elseif(phrase_contains($courses," ")){
  $courses = explode(" ",$courses);   
 }
 
 else{
  $courses = [$courses];
  }
 }
 
 //trim all Courses    
 $trimedCoures = [];
 foreach ($courses as $course){
 $trimcourse = trim($course);
  $trimedCoures[] = $trimcourse;//build Courses array back  
 }
 
 return $trimedCoures;   
    
}

function check_eligible_applicant($era_db,$std_id,$course){
global $site,$Director,$cutoffMark;
$eligibility = true;
 
  if(!$std_id){
  
  $_SESSION["error_msg"] = "Please login to continue your Application";    
   
  $eligibility = false;   
  }
 elseif(!is_available($course)){
     
 $_SESSION["error_msg"] = "Sorry, One or more of the selected course(s) is/are not available at the moment, Please try again later";    
  $eligibility = false;     
     
 }
  
 else{
 
$coresDet = collect_user_data($era_db,"Calendars","Course_Pair",$course,"s");

if($coresDet){
 $pre = $coresDet["Pre_Requisites"];
 
}
else{
  //apply auto search 
  $pre = auto_search_pre($course);  

 if($pre == "no-application"){
 
  $_SESSION["error_msg"] = "No Application Session for the selected Course at the moment, Please try again later";  
  $eligibility = false;
  $pre = null; 
     
 }
}

 
 if($pre){
     
 $preArray = convert_to_array($pre);
 
foreach ($preArray as $required_course){
 
 $det = collect_user_data2($era_db,"Fees","Std_ID","Course",$std_id,$required_course,"is");
 $course_status = strtolower($det["Course_Status"]);
  
 if($course_status !== "completed" && $course_status !== "done"){
      
  $eligibility = false; 
 
 $_SESSION["error_msg"] = "You must be done with $required_course before you can apply for $course.<br>If you are a DE-Student or a Developer, then you need to apply for $required_course exam and get a minimum grade points of $cutoffMark% before you can further your Application.<br>This restriction was placed by the $Director of $site so as to ensure that students don't miss out any core course.";    
 
 
  }
 }
   
   }    
  }
 

 return $eligibility;
}

function auto_search_pre($cores){
  global $era_db;

  $pairpre = "no-application"; 
 $allCores = collect_table_data($era_db,"Calendars","","Course_Pair");

foreach ($allCores as $cose){
    
  $coses = convert_to_array($cose);
  if(in_array($cores,$coses)){
  
  $pair = $cose; //course pair detected
 
  $pairDet = collect_user_data($era_db,"Calendars","Course_Pair",$pair,"s");

if($pairDet){
 $pairpre = $pairDet["Pre_Requisites"];
 
}

 return $pairpre;
   
 }

}


 return $pairpre;   
}

function estimate_course_duration($era_db, $course, $return_format = 'weeks') {
    $course_contents = collect_table_data1($era_db, "Available_Courses","Course",$course,"s");
    $total_weeks = 0;

    // Step 1: Sum up all durations in weeks
    foreach ($course_contents as $content) {
        if ($content["Course"] === $course) {
            $raw_duration = strtolower(trim($content["Course_Duration"]));
            
            // Match number and unit
            if (preg_match('/(\d+)\s*(week|weeks|month|months|year|years)/', $raw_duration, $matches)) {
                $value = (int)$matches[1];
                $unit = $matches[2];

                switch ($unit) {
                    case 'week':
                    case 'weeks':
                        $total_weeks += $value;
                        break;
                    case 'month':
                    case 'months':
                        $total_weeks += $value * 4;
                        break;
                    case 'year':
                    case 'years':
                        $total_weeks += $value * 52;
                        break;
                }
            }
        }
    }

    // Step 2: Breakdown to years, months, weeks
    $years = floor($total_weeks / 52);
    $remaining_weeks = $total_weeks % 52;

    $months = floor($remaining_weeks / 4);
    $weeks = $remaining_weeks % 4;

    $parts = [];

    // Helper to apply pluralization
    $format_unit = function($value, $label) {
        return $value . ' ' . ($value == 1 ? $label : $label . 's');
    };

    if ($return_format === 'years') {
        if ($years > 0)  $parts[] = $format_unit($years, "year");
        if ($months > 0) $parts[] = $format_unit($months, "month");
        if ($weeks > 0)  $parts[] = $format_unit($weeks, "week");
        return implode(" and ", $parts);
    }

    if ($return_format === 'months') {
        $total_months = floor($total_weeks / 4);
        $left_weeks = $total_weeks % 4;
        if ($total_months > 0) $parts[] = $format_unit($total_months, "month");
        if ($left_weeks > 0)  $parts[] = $format_unit($left_weeks, "week");
        return implode(" and ", $parts);
    }

    // Default to weeks
    return $format_unit($total_weeks, "week");
}

function numberToRoman($num) {
    // Map of Roman numerals
    $map = [
        'M'  => 1000,
        'CM' => 900,
        'D'  => 500,
        'CD' => 400,
        'C'  => 100,
        'XC' => 90,
        'L'  => 50,
        'XL' => 40,
        'X'  => 10,
        'IX' => 9,
        'V'  => 5,
        'IV' => 4,
        'I'  => 1
    ];

    $result = '';

    foreach ($map as $roman => $value) {
        // Repeat while the number is >= to the current value
        while ($num >= $value) {
            $result .= $roman;
            $num -= $value;
        }
    }

    return $result;
}


function get_learning_session($era_db,$std_id,$learning){
  
 if(strtolower($learning) == "no records found"){
     
  return "None";   
 }

else{
 if(strpos($learning,"&")){
   
  $learningCores = explode("&",$learning);
  
 }
 else{
     
  $learningCores = [$learning];   
     
 }

$sessionArray = [];
foreach ($learningCores as $cores){
 $cores = trim($cores);
 $coresDet = collect_user_data2($era_db,"Fees","Std_ID","Course",$std_id,$cores,"is");  
$session = $coresDet["Session"];

if($session && !in_array($session,$sessionArray)){
 $sessionArray[] = $session;   
 }
}


if($sessionArray){
    
 $learningSession = implode("/",$sessionArray);
   
}
else{
   
 $learningSession = "No Data";  
}


return $learningSession;
 
 }
}

function correct_apply_session(){
 global $era_db,$iniSession,$iniBatch;
  $SesBatch = $iniSession." ".$iniBatch;
 
 $det = collect_user_data2($era_db,"Calendars","Session","Batch",$iniSession,$iniBatch,"ss");
 
 if($det){
     
  $coresPair = $det["Course_Pair"];
  $upd =0;
  
  if(phrase_contains($coresPair,"/")){
   $cores = explode("/",$coresPair);   
   }
  else{
   $cores = [$coresPair];   
  }
  
  
  foreach ($cores as $core){
      
  if(update_user_data($era_db,"Fees","Session","Course",$SesBatch,$core,"ss")){
  $upd++;    
   }    
  }   


if($upd){
    
   $feedback = [
     "status" => "success",
     "message" => "Tutorial Session for existing students updated to $SesBatch successfully ✓"
     ];    
    
}
else{
  $feedback = [
     "status" => "failed",
     "message" => "Failed to update Tutorial Session for existing students. Re: database execution error !"
     ];    
    
}
 
 }
 else{
     
 $feedback = [
     "status" => "failed",
     "message" => "Failed to update Tutorial Session for existing students. Re: Calendar for $SesBatch not set !"
     ];  
 }
  
 return $feedback;   
    
}