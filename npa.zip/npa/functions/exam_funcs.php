<?php

function check_done_all_exams($examOwner,$examOwnerCat){
 global $era_db,$home_db,$adminCats;
 $Done = false;
 
  $AvailableCores = collect_table_data1($era_db,"Fees_Settings","Course_Cat","Web","s","ASC","Course");
 
 $doneExams = collect_table_data3($era_db,"Exams","Std_ID","Course_Cat","Exam_Status",$examOwner,"Web","Done","iss","ASC","Course");

if(in_array($examOwnerCat,$adminCats)){

$examOwnerDet = collect_user_data($home_db,"Admins","Admin_ID",$examOwner,"i");
$dev_cat = strtolower($examOwnerDet["Dev_Cat"]);
$rq = 0;
$required = [];

if($dev_cat == "front end"){
 $required = ['HTML5','CSS'];
  
}
elseif($dev_cat == "back end"){
 
  $required = ['JS','PHP'];
   
}
else{
    $required = $AvailableCores; //all courses 
}  
  
  
 foreach ($required as $require){
   
  if(in_array($require, $doneExams)){
   $rq++;   
   } 
  }
 
if($rq == count($required)){
    
   if(update_user_data($home_db,"Admins","All_Exams","Admin_ID","Done",$examOwner,"si")){
      
  $Done = true;    
  }  
 }
}
else{
 //Students, must write all Exams
 if(count($AvailableCores) == count($doneExams)){
  
  if(update_user_data($era_db,"Students","All_Exams","Std_ID","Done",$examOwner,"si")){
      
  $Done = true;    
  }
 }
    
}
    
  return $Done;  
}
function upload_exam_questions($era_db){
    global $defaultAdmin;
 
  if(isset($_SESSION["upl_cat"])){
      
 $course = $_SESSION["upl_course"];
 $course_code = $_SESSION["course_code"];
     
 echo '<section class="section" id="about">
 <h2>Exam Manager</h2>';

if($_SESSION["upl_cat"] == "ubf"){
    
 echo '<p><small>Upload Exam Questions for '.$course.'</small></p>';
  
    echo '<form action ="includes/exam_manager.inc" method="post" enctype="multipart/form-data" class ="contact-form" id="AssForm">
 
 <input type="file" id="pix" name="file">
   <label for="pix"><i class="fas fa-upload"></i> <span id="preview-pix">Click here to select the file that contains the questions </span></label>
 <button type="submit" name="submit_upload_qst_file">Upload Question</button>
 </form>';  
    
    
}
else{
     
   echo '<p><small>Upload Exam Questions for '.$course_code.'</small></p>';
  echo '<form action ="includes/exam_manager.inc" method="post" enctype="multipart/form-data" class="contact-form" id="AssForm">';
  echo '<label for="qst">Question</label>
    <textarea type="text" id="qst" name="qst" rows="5" placeholder="Type your question here..." required autofocus></textarea>
  
    <label for="opt1">Option 1</label>
   <input type="text" id="opt1" name="opt1" placeholder="Enter the first option" required>
   
   <label for="opt12">Option 2</label>
   <input type="text" id="opt2" name="opt2" placeholder="Enter the second option" required>
   
   <label for="opt3">Option 3</label>
   <input type="text" id="opt3" name="opt3" placeholder="Enter the third option" required>
   
   <label for="opt4">Option 4</label>
   <input type="text" id="opt4" name="opt4" placeholder="Enter the fourth option" required>
    
     <small>Which option has the correct answer?</small>
    <div class="choose_ans">
    <input type="radio" id="ans1" name="ans" value="opt1" required><label for="ans1">Option 1</label>
    
     <input type="radio" id="ans2" name="ans" value="opt2" required><label for="ans2">Option 2</label>
  
      <input type="radio" id="ans3" name="ans" value="opt3" required><label for="ans3">Option 3</label>
      
       <input type="radio" id="ans4" name="ans" value="opt4" required><label for="ans4">Option 4</label>
    </div>
   
  <input type="file" id="pix" name="pix" accept="image/*">
   <label for="pix"><i class="fas fa-upload"></i> <span id="preview-pix">Attach a picture (Optional)</span></label>
   
  <button type="submit" name="submit_upload_qst" value="new">Upload</button>
  </form>';  
    
    
}
 

  echo '<div id="spinner"></div>';
       
  echo '</section>';    
      
  }
  else{
      
echo '<section class="section" id="about">

<div class="dropdown">
  <button onclick="toggleDropdown()" class="dropbtn"> &#9660;</button>
  <div id="myDropdown" class="dropdown-content">
  <p>Select an Action</p> 
    
    <input type ="button" onclick="newAction(1)" value="Upload Questions">    
  
    <input type ="button" onclick="newAction(2)" value="Edit Questions">
    
    <input type ="button" onclick="newAction(3)" value="Exam Schedule">
  
  <input type ="button" onclick="newAction(4)" value="View Results">
      
    </div></div>


 <h2>Exam Manager</h2>
<p>
<small>Select the category of questions you which to upload</small></p>
<form action ="includes/exam_manager.inc" method="post" enctype="multipart/form-data" class="contact-form" id="AssForm">';
  

echo '<label>Select Course</label>
   <select id="course" name="course" onchange="showCourseCodes()" required>';
  $cores = collect_table_data($era_db,"Fees_Settings","ASC");
  foreach ($cores as $core){
      
   $course = $core["Course"];
//show all introduced courses
   echo '<option>'.$course.'</option>';   
     
 }
  echo '</select>';

echo '<label>Select Course Code <span id="spinner2"></span></label>
   <select id="course_code" name="course_code" required></select>

<div class= "termsCond">
  <input type="checkbox" id="terms" name="ubf"><label for="terms">Upload questions by file</label>
         </div>
   <button type="submit" name="submit_qst_cat">Next</button>
  </form>
  <div id="spinner"></div>
 
  </section>';    
    
  }

 echo '<script>
 
  document.getElementById("AssForm").addEventListener("submit",(e)=>{
  
 document.getElementById("spinner").style.display = "flex"; 
  
  });
        
        
  </script>';
}

function  show_edit_qsts($era_db,$qst_Id,$course_code,$admin_id,$admin_cat){
global $defaultAdmin;
    echo '<section class="section" id="about">
 <h2>Exam Manager</h2>';
  
 if($qst_Id && $course_code){
  // edit this qst   
  
 $qst = collect_user_data2($era_db,"Questions","id","Course_Code",$qst_Id,$course_code,"is");
 
   $q = $qst["Question"];
   $a = $qst["A"];
   $b = $qst["B"];
   $c = $qst["C"];
   $d=  $qst["D"];
   $ans = $qst["Answer"];
   
echo '<p><small>Update Exam Questions on '.$course_code.'</small></p>';
  
  echo '<form action ="includes/exam_manager.inc" method="post" enctype="multipart/form-data" class="contact-form" id="AssForm">';
  echo '<label for="qst">Question</label>
    <textarea type="text" id="qst" name="qst" rows="5" placeholder="Type your question here..." required autofocus>'.$q.'</textarea>
  
    <label for="opt1">Option 1</label>
   <input type="text" id="opt1" name="opt1" placeholder="Enter the first option" value="'.$a.'" required>
   
   <label for="opt12">Option 2</label>
   <input type="text" id="opt2" name="opt2" placeholder="Enter the second option" value="'.$b.'"  required>
   
   <label for="opt3">Option 3</label>
   <input type="text" id="opt3" name="opt3" placeholder="Enter the third option" value="'.$c.'" required>
   
   <label for="opt4">Option 4</label>
   <input type="text" id="opt4" name="opt4" placeholder="Enter the fourth option" value="'.$d.'" required>
    
     <small>Answer:<em><strong> '.$ans.' </strong></em><br>Change answer to:</small>
    <div class="choose_ans">
    <input type="radio" id="ans1" name="ans" value="opt1" ><label for="ans1">Option 1</label>
    
     <input type="radio" id="ans2" name="ans" value="opt2" ><label for="ans2">Option 2</label>
  
      <input type="radio" id="ans3" name="ans" value="opt3" ><label for="ans3">Option 3</label>
      
       <input type="radio" id="ans4" name="ans" value="opt4" ><label for="ans4">Option 4</label>
    </div>
  
   <input type="hidden" id="qst_Id" name="qst_Id" value="'.$qst_Id.'" >
  
  <input type="file" id="pix" name="pix" accept="image/*">
   <label for="pix"><i class="fas fa-upload"></i> <span id="preview-pix">Attach a picture (Optional)</span></label>
   
  <button type="submit" name="submit_upload_qst" value="update">Update</button>
  </form>
<div id="spinner"></div>';
 
 }
 
elseif($course_code && !$qst_Id){
  // show all qst on this code by this $uploader to enable him select the qst to eidt
 

 echo '<p><strong>Your Questions on '.$course_code.'</strong></p>';

if(isset($_SESSION["editall"]) && $admin_cat == $defaultAdmin){
 // edit the selected course no matter the Uploader   
    
 $Qsts = collect_table_data($era_db,"Questions","ASC");
 
 $sn = 0;
 foreach ($Qsts as $qst){
   
   $Id = $qst["id"];
   $uploader = $qst["Uploader"];
   $code = $qst["Course_Code"];
   $q = $qst["Question"];
   $a = $qst["A"];
   $b = $qst["B"];
   $c = $qst["C"];
   $d=  $qst["D"];
   $ans = $qst["Answer"];
   
   
 if($code == $course_code){
  $sn++;     
  echo '<p><small>
  Q'.$sn.': '.$q.'<br>
  A: '.$a.'<br>
  B: '.$b.'<br>
  C: '.$c.'<br>
  D: '.$d.'<br>
  Ans: '.$ans.'<br>
  </small>
  <a class="link_btn" id ="view_link_btn" href="exam_manager?edit_qsts&course_code='.$course_code.'&qst_Id='.$Id.'">Edit</a>  
  
  <hr>
  <p>';     
       
   }
 }

}
 else{
//edit only qst by uploader     

$Qsts = collect_table_data($era_db,"Questions","ASC");
 
 $sn = 0;
 foreach ($Qsts as $qst){
   
   $Id = $qst["id"];
   $uploader = $qst["Uploader"];
   $code = $qst["Course_Code"];
   $q = $qst["Question"];
   $a = $qst["A"];
   $b = $qst["B"];
   $c = $qst["C"];
   $d = $qst["D"];
   $ans =  $qst["Answer"];
   
   
 if($code == $course_code && $admin_id == $uploader){
  
   $sn++;
       
  echo '<p><small>
  Q'.$sn.': '.$q.'<br>
  A: '.$a.'<br>
  B: '.$b.'<br>
  C: '.$c.'<br>
  D: '.$d.'<br>
  Ans: '.$ans.'<br>
  </small><br>
  <a class="link_btn" id="view_link_btn" href="exam_manager?edit_qsts&course_code='.$course_code.'&qst_Id='.$Id.'">Edit</a>
  
  <hr>
  </p>';     
       
   }
  }
 }
 
 
  if($sn == 0){
     
 echo '<p>
 <br><center><i id="warning" class= "fas fa-exclamation-triangle"></i><br> No records found</center></p><hr>';  
 
  }
 
}
 else{
  // select $course_code   
 echo '<p>
  <small>Select the category of questions you which to edit</small></p>
<form action ="includes/exam_manager.inc" method="post" enctype="multipart/form-data" class="contact-form" id="AssForm">';
  

echo '<label>Select Course</label>
   <select id="course" name="course" onchange="showCourseCodes()" required>';
  $cores = collect_table_data($era_db,"Fees_Settings","ASC");
  foreach ($cores as $core){
      
   $course = $core["Course"];
//show all introduced courses
   echo '<option>'.$course.'</option>';   
     
 }
  echo '</select>';

echo '<label>Select Course Code <span id="spinner2"></span></label>
   <select id="course_code" name="course_code" required></select>';

if($admin_cat == $defaultAdmin){
  
  echo '<div class= "termsCond">
  <input type="checkbox" id="terms" name="editall"><label for="terms">Edit all questions</label>
         </div>';
    
}


  echo '<button type="submit" name="submit_edit_qst_cat">Next</button>
  </form>
  <div id="spinner"></div>';    
       
    
 }
 
 
echo '</section>'; 

   echo '
  <style>
  
  #view_link_btn{
      position:relative;
      left:80%; bottom:10px;
  }

.section #warning{
 display:flex;
  justify-content:center;
 align-items:center;
     color:hsl(0,40%,60%);
     font-size:30px;
     margin-bottom:10px;
   
 }
 ;
  </style>
   <script>
 
  document.getElementById("AssForm").addEventListener("submit",(e)=>{
  
 document.getElementById("spinner").style.display = "flex"; 
  
  });
        
        
  </script>';  
}
 
 function show_exam_schedule($era_db,$user_id,$user_cat,$schdStatus,$tutor_consent){

 global $stdCats,$adminCats,$defaultAdmin;
global $home_db,$era_db;

 if(isset($_SESSION["admin_id"])){

 $admin_id = $_SESSION["admin_id"];
 $admin_cat = $_SESSION["admin_cat"];
    
 }
 
 if(!$schdStatus){
     $schdStatus = "Pending";
 }
 


 if($tutor_consent == "Yes" && $admin_cat == $defaultAdmin){
//tutors     
  $small =  "Showing all $schdStatus Exam Schedule by your Students"; 
  $NoRecord ="No records found for your Students";
  
     $dir1 = "admin";
     $btn1 = "Back to Dashboard";  
  
 }
 else{

  $small =  "Showing all your $schdStatus Exam Schedule"; 
  $NoRecord ="You don't have any $schdStatus Schedule";
  
   $dir1 = "?schedule_an_exam";
   $btn1 = "Schedule an Exam";
 }
 

 echo '<section class="section" id="about">
 <h2>Exam Schedule</h2>';

echo '<p><small>'.$small.'</small></p>';
  
  $schedule = collect_table_data1($era_db,"Exams","Exam_Status",$schdStatus,"s","ASC");
  
  
  if($schedule){

 $checkSchedule = check_exam_schedule($era_db,$user_id,$admin_cat,$schdStatus,$tutor_consent); //return true or false


if($checkSchedule){
   
 echo '<center><div class="courses-table">
 <table>
  <tr>
  <th>S/N</th>';
 
 if($tutor_consent =="Yes" || $admin_cat ==$defaultAdmin){
     
  echo '<th>Student Name</th>
   <th>Student Category</th>';   
     
 }
 
 echo '<th>Course</th>
  <th>Schedule </th>
  <th>Question Numbers</th>
  <th>Duration</th>';
  
  if($schdStatus == "Done"){
      
    echo '  
  <th>Questions Answered</th>
  <th>Time_Spent</th>';  
      
  }
  
  echo '<th>Assessment Points (30%)</th>
  <th>Exam Points (70%)</th>
  <th>Exam Status</th>
  <th>Action Buttons</th>
  </tr>';  
    
   
  foreach ($schedule as $schd){
      
  $exam_Id = $schd["id"];
  $tutor = $schd["Std_Tutor"];
  $std = $schd["Std_ID"];
  $std_cat = $schd["Std_Cat"];
  $cores = $schd["Course"];
  $exam_schd = $schd["Exam_Schedule"];
  $qst_num = $schd["Qst_Num"];
  $duration = $schd["Exam_Duration"];
  $AssPoints = $schd["Assignment_Points"];
  $ExamPoints = $schd["Exam_Points"];
  $ExamStatus = $schd["Exam_Status"];
  $examFee = $schd["Exam_Fee"];
 $examFeeStatus =$schd["Exam_Fee_Status"];
 $qst_ans = $schd["Qst_Answered"];
 $timespent = $schd["Time_Spent"];
  $certificate = $schd["Certificate"];
  
  $NoFees = ['Student','Developer'];
  
  if(in_array($std_cat,$stdCats)){
  $conn = $era_db;
  $table = "Students";
  $id_col = "Std_ID";
      
  }
 elseif(in_array($std_cat,$adminCats)){
     
  $conn = $home_db;
  $table = "Admins";
  $id_col = "Admin_ID";
     
 } 
  
  $stdDet = collect_user_data($conn,$table,$id_col,$std,'i');
  $std_name = $stdDet["SurName"]." ".$stdDet["OtherNames"];
  
  if($ExamStatus == $schdStatus){
   
   if($std == $user_id || $tutor == $admin_id || $admin_cat == $defaultAdmin){
 $sn++;
 
   echo '<tr>
  <td>'.$sn.'.</td>';
   if($tutor_consent =="Yes" || $admin_cat ==$defaultAdmin){
 
 echo '<td>'.$std_name.'</td>
 <td>'.$std_cat.'</td>';
   }
  
  echo '<td>'.$cores.'</td>
   <td>'.$exam_schd.'</td>
 <td>'.$qst_num.'</td>
 <td>'.$duration.' Mins</td>';
 if($schdStatus =="Done"){
  
  echo ' 
  <td>'.$qst_ans.'</td>
 <td>'.$timespent.'</td>';  
     
 }
 
echo '<td>'.$AssPoints.'</td>
 <td>'.$ExamPoints.'</td>
 <td>'.$ExamStatus.'</td>
 <td><span class="table_btn">';
 
 if($ExamStatus == "Pending"){
     
  if($examFeeStatus != "Paid" && !in_array($std_cat,$NoFees)){
      
   echo '<a id="grade_ass" href="?pay_exam_fees&exam_id='.$exam_Id.'&std_id='.$std.'&std_tutor='.$tutor.'">Exam Fee</a>';   
      
  }
    
 echo '<a id="view_ass" href="?cancel_this_exam&exam_id='.$exam_Id.'&std_id='.$std.'&std_tutor='.$tutor.'">Cancel Exam</a>';
 
  if($user_id == $std){
      
 echo '<a id="dwn_ass" href="?start_this_exam&exam_id='.$exam_Id.'&std_id='.$std.'">Start Exam</a>';  
  }
 }
  elseif($ExamStatus == "Cancelled"){
      
  if($admin_id == $tutor || $admin_cat == $defaultAdmin){
      
  echo '<a id="view_ass" href="?reverse_cancel_this_exam&exam_id='.$exam_Id.'&std_id='.$std.'&std_tutor='.$tutor.'">Reverse Cancellation</a>';
       
    }
    
    else{
   
   echo '<i>None</i>';  
      
   }
  }
      
 elseif($ExamStatus == "Done"){
  
  echo '<a id="view_ass" href="/results?view_this_result&exam_id='.$exam_Id.'&std_id='.$std.'&std_tutor='.$tutor.'">View Details</a>';   
  
  if($admin_cat == $defaultAdmin){
      
     echo '<a id="dwn_ass" href="?Reverse_this_exam_warning&exam_id='.$exam_Id.'&std_id='.$std.'&std_tutor='.$tutor.'" style="font-size:10px;">Reverse Exam</a>';  
  if($certificate){
    
 $_SESSION["remove_cert_init"] = "truely-truely";
    
     echo '<a id="share_cert" href="?Remove_this_cert_warning&exam_id='.$exam_Id.'&std_id='.$std.'&std_tutor='.$tutor.'" style="font-size:10px;">Remove Cert</a>';  
      
        }
     
      }
    
   }
   
  else{
   
   echo '<i>None</i>';  
      
  }

  echo '</span></td>
  </tr>';
    }  
   }
  }
echo '</table>
  </div></center><br>';  
  
}
else{
// there is records but not for this viewer    
 echo '<p>
 <br><center><i id="warning" class= "fas fa-exclamation-triangle"></i><br>'.$NoRecord.'</center>
 </p><hr>';  
      
}
  }
 else{
 // No records in the db at all    
 echo '<p>
 <br><center><i id="warning" class= "fas fa-exclamation-triangle"></i><br> No records found</center></p><hr>';  
     
 } 
 
    addBtn($btn1,$dir1);
 
  if($schdStatus == "Pending"){
      
  $btn = "View Cancelled Schedule";
  $dir = "?view_exam_schedule&schd_status=Cancelled";
    addBtn($btn,$dir);
      
  }
  elseif($schdStatus == "Cancelled" || $schdStatus=="Done"){
      
  $btn = "View Pending Schedule";
  $dir = "?view_exam_schedule&schd_status=Pending";
    addBtn($btn,$dir);
 
  }
 
 if($schdStatus != "Done" && $admin_cat == $defaultAdmin){
     
  $btn = "View Taken Exams";
  $dir = "?view_exam_schedule&schd_status=Done";
    addBtn($btn,$dir);
    
     
 }
 
 echo '</section>';
     
 }
 
 function check_exam_schedule($era_db,$user_id,$user_cat,$schdStatus,$tutor_consent){
 global $defaultAdmin;
 
 //return true or false    
     
  if(check_exist2($era_db,"Exams","Std_ID","Exam_Status",$user_id,$schdStatus,"is")){
      
   return true;   
      
  }
  elseif(check_exist($era_db,"Exams","Exam_Status",$schdStatus,"s")){

  if($user_cat == $defaultAdmin || $tutor_consent == "Yes"){
      
   
   return true;      
     
      
  }
  else{
      
   return false;   
      
   }
  }
  
 else{
     return false;
  } 

 } 
 
  function schedule_an_exam($era_db,$std_id,$std_cat){
   global $defaultAdmin;
   
 echo '<section class="section" id="about">
 <h2>Schedule an Exam</h2>';
 
 echo '<small>Schedule your Exams as it pleases you</small>';
   
  echo '<form action ="/includes/exams.inc" method="post" enctype="multipart/form-data" class="contact-form" id="AssForm">';
 
 echo '<input type="hidden" name="user_id" value="'.$std_id.'">
 <input type="hidden" name="user_cat" value="'.$std_cat.'">
 
<label>Select Course</label>
   <select id="course" name="course" required>';
  $cores = collect_table_data($era_db,"Fees_Settings","ASC");
  foreach ($cores as $core){
      
   $course = $core["Course"];
   
   echo '<option>'.$course.'</option>';   
    
 }
  echo '</select>';


echo '<label>Set Exam Date</label>
<input type="date" name="exam_date" required>
<label>Set Exam Time</label>
<input type="time" name="exam_time" required>
 <label>Set Exam Reminder</label>
   <select id="reminder" name="reminder">
<option value="0">Don\'t Remind me</option>
 <option value="1">Remind me 1 day to the Exam</option>
 <option value="2">Remind me 2 days to the Exam</option>
 <option value="3">Remind me 3 days to the Exam</option>
  </select>
<button type="submit" name="submit_new_exam_schd">Submit Schedule</button>
</form>
<div id="spinner"></div>
 </section>';  
    
 echo '<script>
 
 document.getElementById("AssForm").addEventListener("submit",(e)=>{
  
 document.getElementById("spinner").style.display = "flex"; 
  
  });
        
  </script>'; 
 
 } 
   
 function done_with_courses($era_db,$user_id,$course){
   global $defaultAdmin;
   
 
 $Available = collect_table_data1($era_db,"Available_Courses","Course",$course,"s");
 
 $DoneCourses = collect_table_data2($era_db,"Courses_Done","Std_ID","Course",$user_id,$course,"is");
 
 $AvailableCodes = [];
 $DoneCodes = [];
 
 foreach ($Available as $avail){
   
  $cores = $avail["Course"];
  $code = $avail["Course_Code"];
  
   if($cores == $course){
       
     $AvailableCodes[] = $code;
   }  
     
 }
     
  foreach ($DoneCourses as $done){
   
  $cores = $done["Course"];
  $code = $done["Course_Code"];
  $codeStatus = $done["Course_Status"];
  $Id = $done["Std_ID"];
  
  
   if($cores == $course && $Id == $user_id && $codeStatus == "Done"){
       
     $DoneCodes[] = $code;
   }  
     
 }    
  
 if(count($AvailableCodes) == count($DoneCodes)){
  //all course contents has been done    
 return true;    
     
 }
 else{
     return false;
  }
 
 }
 
 function get_Work_Points($era_db,$user_id,$course){
 global $defaultAdmin;
     
  $DoneCourses= collect_table_data($era_db,"Courses_Done","ASC");
  
  $Points = [];
  
  foreach ($DoneCourses as $done){
   
  $Id = $done["Std_ID"];
  $cores = $done["Course"];
  $codeStatus = $done["Course_Status"];
  $codePoint = $done["Assignment_Points"];
  
  
   if($cores == $course && $Id == $user_id && $codeStatus == "Done"){
       
     $Points[] = $codePoint;
   }  
     
 }  
  
  if($Points){
      
   $totalPoints = round(array_sum($Points)/count($Points),2);   
    
  }
  else{
   
   $totalPoints = 0;   
      
  }
  
    
  return $totalPoints;   
 }

function cancel_this_exam($era_db,$exam_Id,$std_Id,$tutor_Id,$NewExamStatus,$request){
 global $defaultAdmin;
  
 if(isset($_SESSION["admin_id"])){

 $admin_id = $_SESSION["admin_id"];
 $admin_cat = $_SESSION["admin_cat"];
    
 }    
  
 $examDet = collect_user_data($era_db,"Exams","id",$exam_Id,"i");   
 $examOwner = $examDet["Std_ID"];
 $examOwnerCat = $examDet["Std_Cat"];
 $IniExamStatus = $examDet["Exam_Status"];
 $examFeeStatus = $examDet["Exam_Fee_Status"];
 $examCores = $examDet["Course"];
 $std_tutor = $examDet["Std_Tutor"];
 
 if($examFeeStatus == "Paid" && $request == "Cancel"){
   // Cancellation denied
     
$_SESSION["error_msg"] = "Exam Cancellation denied !<br>
  Reasons: Exam fees already paid";
      
     
  echo '<script>
  window.location = document.referrer;
  </script>';
  exit();   
     
 }
 
 
 if($IniExamStatus == "Pending" || $request =="Reverse"){
     
   if($std_Id == $examOwner && $request =="Cancel"){
       
    if(Update_data($era_db,"Exams","Exam_Status","id",$NewExamStatus,$exam_Id,"si")){
        
  $_SESSION["success_msg"] = "Your Exam Schedule for $examCores has been $NewExamStatus successfully ✓";
   }
   else{
       
    $_SESSION["error_msg"] = "Unable to $request the selected Exam Schedule<br>
  Reasons: Error executing Database Query";
    
    }
       
  }
  else{
  // tutor/Default admin access to Cancel a Schedule
  
 if($admin_id == $std_tutor || $admin_cat == $defaultAdmin){
     
if(Update_data($era_db,"Exams","Exam_Status","id",$NewExamStatus,$exam_Id,"si")){
        

if($request =="Cancel"){
 
    $_SESSION["success_msg"] = "You have successfully Cancelled the Exam Schedule on $examCores for the selected Student";
  
    
}
elseif($request == "Reverse"){
    
  $_SESSION["success_msg"] = "You have successfully Reversed the Cancellation of $examCores Exam Schedule for the selected Student";   
   }

  }
   else{
       
    $_SESSION["error_msg"] = "Unable to $request the selected Exam Schedule Status<br>
  Reasons: Error executing Database Query";
    
     }
   } 
   else{
       
  $_SESSION["error_msg"] = "Unable to $request the selected Exam Schedule Status<br>
  Reasons: Unknown User Category";
      
       
   }
  }   
 }
 
 elseif($admin_cat == $defaultAdmin && $request = "Reverse-Exam"){
     
  if($IniExamStatus == "Done"){
  
  if(Update_data($era_db,"Exams","Exam_Status","id",$NewExamStatus,$exam_Id,"si")){    
  
  Update_data($era_db,"Exams","Total_Points","id","Pending",$exam_Id,"si"); // set exam Points back to Pending
      
  //clear Exam_History 
   
   delete_data3($era_db,"Exam_History","Std_ID","Std_Cat","Course",$examOwner,$examOwnerCat,$examCores,"iss");
   
    $_SESSION["success_msg"] = "You have successfully Reversed the written exam  on $examCores by the $examOwnerCat with Id $examOwner"; 
   }
   else{
       
 $_SESSION["error_msg"] = "Unable to $request <br>
 Reasons: Error executing Database Query";  
    }
      
  }   
  else{
       
   $_SESSION["error_msg"] = "Unable to $request.<br>
  Reasons: Exam not yet taken";
       
   }  
     
 }
 else{
  
  $_SESSION["error_msg"] = "Unable to $request the selected Exam Schedule Status<br>
  Reasons: Exam already $IniExamStatus";
     
 }
 
 
 if($admin_id == $std_tutor || $admin_cat == $defaultAdmin){

echo '<script>
  window.location = "/exam_manager?view_exam_schedule";
  </script>';
  exit();
   
 }
 else{
     
echo '<script>
  window.location = "/exams";
  </script>';
  exit();     
   }

 }

function current_course_session(array $codes): ?string {
    if (empty($codes)) {
        return null; // handle empty array safely
    }

    usort($codes, function($a, $b) {
        // Extract numeric year and letter using regex
        preg_match('/(\d+)([A-Z])/i', $a, $a_parts);
        preg_match('/(\d+)([A-Z])/i', $b, $b_parts);

        $yearA = (int)($a_parts[1] ?? 0);
        $yearB = (int)($b_parts[1] ?? 0);

        $letterA = strtoupper($a_parts[2] ?? '');
        $letterB = strtoupper($b_parts[2] ?? '');

        // Compare by year first
        if ($yearA !== $yearB) {
            return $yearB <=> $yearA; // descending order (highest year first)
        }

        // Compare by letter if years are equal
        return strcmp($letterB, $letterA); // descending by letter
    });

    return $codes[0]; // the highest after sorting
}

function initiate_exam($era_db,$std_Id,$exam_Id,$DayDateTime,$naira){
 global $defaultAdmin,$supportAdmin;
   
 $examDet = collect_user_data($era_db,"Exams","id",$exam_Id,"i");   
 $examOwner = $examDet["Std_ID"];
 $ExamStatus = $examDet["Exam_Status"];
 $examCores = $examDet["Course"];
 $std_tutor = $examDet["Std_Tutor"];
 $examOwnerCat = $examDet["Std_Cat"];
 $examFeeStatus = $examDet["Exam_Fee_Status"];
$examFee = number_format($examDet["Exam_Fee"],2);
 $examSchedule= $examDet["Exam_Schedule"];
 
 $schdstrtoTime = strtotime(str_replace('/','-',$examSchedule));
 $todaystrtoTime = strtotime(str_replace('/','-',$DayDateTime));
 
$NoFees = ['Student','Developer',$supportAdmin,$defaultAdmin];
if($ExamStatus == "Pending"){
 
 if($examFeeStatus == "Paid" || in_array($examOwnerCat,$NoFees)){
 
  if($todaystrtoTime >= $schdstrtoTime){
    //all conditions satisfied
  
  $_SESSION["start_exam"] = "true";
    
   echo '<input type="hidden" id="exam_Id" value="'.$exam_Id.'">
   <input type="hidden" id="exam_cores" value="'.$examCores.'">';
    
    echo '<script>
  const ExamId = document.getElementById("exam_Id").value;
const ExamCores = document.getElementById("exam_cores").value;


 const tittle =`START ${ExamCores} EXAM`;
 const msg1 = "Are you sure you wants to start this exam now?";
 const msg2 = "Once exam is started, you are not allowed to minimize or navigate to another page or reloading the page or closing the browser. Failure to comply with this rules will lead to automatic submission and end of exam.";
 const link = `start_exam?exam_Id=${ExamId}`;
 const cancel = "exams?msg_report=Exam Initialization cancelled !&report=failed";
 
 const linkLabel = "Start Exam Now";
 const cancelLabel = "Start Exam Later";
  const save = false;    
   showAlert(tittle,msg1,msg2,link,cancel,linkLabel,cancelLabel,save);   


 // window.location = `start_exam?exam_Id=${ExamId}`;
  </script>';
     
      
  }   
  else{
  
  $_SESSION["error_msg"] = "Unable to Initiate the selected Exam<br>
  Reasons: The Scheduled Date-Time for the selected Exam is not yet due";
    
echo '<script>
  window.location = document.referrer;
  </script>';
  exit();     
      
      
  }   
     
 }
 else{
 
  $_SESSION["success_msg"] = 'Unable to Initiate the selected Exam<br>
  Re: Exam fee for the selected Exam has not been Paid<br>
  Fee Amount: '.$naira .$examFee.'<br>
  Payment Status: '.$examFeeStatus.' <a id="payLink" href="?pay_exam_fees&exam_id='.$exam_Id.'">Pay</a>';
    
echo '<script>
  window.location = document.referrer;
  </script>';
  exit();   
     
 }
}
else{
 
   $_SESSION["error_msg"] = "Unable to Initiate the selected Exam<br>
  Reasons: Exam already $ExamStatus";
     
      
echo '<script>
  window.location = document.referrer;
  </script>';
  exit();   
}

  
}

function end_this_exam($era_db,$exam_Id,$examCores,$examOwner,$examOwnerCat,$ans_qst,$total_qst,$DayDateTime,$Time){
 
global $defaultAdmin;
  
  $examDet = collect_user_data($era_db,"Exams","id", $exam_Id,"i");
  $AssPoints = $examDet["Assignment_Points"];
 $tutor_Id = $examDet["Tutor_ID"];
 
  if(!$total_qst){
     $total_qst = $examDet["Qst_Num"];
 }
 
 
if(isset($_SESSION["start_time"])){
    
 $start_time = $_SESSION["start_time"];  
 
$Current_time = $Time; 
 $secondspent = $Current_time - $start_time;
 
$timespent = sec_to_time($secondspent);
     
}

if(!$timespent){
    $timespent = "Undetermined";
}
 
 $thisCores = collect_table_data2($era_db,"Exam_History","Std_ID","Course",$examOwner,$examCores,"is");
 
if($thisCores){

 if(count($thisCores) > $total_qst){
     
  $endDetails = [
      "status" => "failed",
      "error" => "You answered more than the required question number",
      "scores" => "",
      "timespent" => ""
      ];  
  
  return $endDetails;   
     
 }
 else{
  $examScores = 0;   
 foreach ($thisCores as $core){
 $selectedOption = $core["Option_Selected"];
 $correctOption = $core["Correct_Option"];
  
  if($selectedOption == $correctOption){
      
   $examScores++;   
      
  }
 }
 
 if(!$AssPoints || !is_numeric($AssPoints)){
 
 if($examScores <= 50){
     
 $AssPoints = 27;  
         
 }
 else{
 $AssPoints = 28;    
 }

update_user_data($era_db,"Exams","Assignment_Points","id",$AssPoints,$exam_Id,"si");


 }

 
 $examScoreable = 70;
 $modifiedScores = round(($examScoreable/$total_qst)*$examScores,0);
 
 if($modifiedScores > $examScoreable){
     
    $modifiedScores = $examScoreable;
 }
 

 $total_points = $AssPoints + $modifiedScores; 
$prefix = "None"; //return only letter without number prefix like A1 should be A, B2 should be B 
 $GradeRemark = result_grade($total_points,$prefix);
 $grade = $GradeRemark["grade"];
 $remark = $GradeRemark["remark"];
 

 update_user_data($era_db,"Exams","Exam_Status","id","Done",$exam_Id,"si");
 
 update_user_data($era_db,"Exams","Date_Taken","id",$DayDateTime,$exam_Id,"si");

 update_user_data($era_db,"Exams","Tutors_Remark","id",$remark,$exam_Id,"si");
 
 update_user_data($era_db,"Exams","Time_Spent","id",$timespent,$exam_Id,"si");

 update_user_data($era_db,"Exams","Qst_Answered","id",$ans_qst,$exam_Id,"si");
  
 update_user_data($era_db,"Exams","Exam_Points","id",$modifiedScores,$exam_Id,"si");
 
 update_user_data($era_db,"Exams","Total_Points","id",$total_points,$exam_Id,"si");

  update_user_data($era_db,"Exams","Grade","id",$grade,$exam_Id,"si");
  
 global $cutoffMark;
 if($total_points >= $cutoffMark){
   //std must score a minimum of Course_Status to be done with courses, check constants to know ths value.   
  
 $ExamStatus = "Done";   
   if(check_exist3($era_db,"Fees","Std_ID","Std_Cat","Course",$examOwner,$examOwnerCat,$examCores,"iss")){
 
 update_user_data3($era_db,"Fees","Course_Status","Std_ID","Std_Cat","Course",$ExamStatus,$examOwner,$examOwnerCat,$examCores,"siss");
       
  }
  else{
 //DE-Student or Developer
  $applyFee = "0";//No application Fee
  $tuitionFee = "0"; //No tuition 
  $applyFeesStatus = "Paid";
  
 //get session batch.
 $courses = collect_table_data($era_db,"Calendars","","Course_Pair");
 
 foreach ($courses as $cose){
  $coseArray = convert_to_array($cose);
  if(in_array($examCores,$coseArray)){
      
  $cosePair = $cose;    
   break;   
  }
 }
 
 $ses = collect_table_data1($era_db,"Calendars","Course_Pair",$cosePair,"s","","Session");
 
$curSes = current_course_session($ses);
 $sesDet = collect_user_data2($era_db,"Calendars","Session","Course_Pair",$curSes,$cosePair,"ss");
 $batch = $sesDet["Batch"];
 $sesbatch = $curSes." ".$batch;

  $data = [
      "conn" => $era_db,
      "table" => "Fees",
      "cols" => ['Std_ID','Std_Cat','Tutor_ID','Course','Course_Status','Apply_Fee','Apply_Fee_Status','Tuition_Fee','Tuition_Fee_Payable','Tuition_Fee_Status',"Session"],
      "vals" => [$examOwner,$examOwnerCat,$tutor_Id,$examCores,$ExamStatus,$applyFee,$applyFeesStatus,$tuitionFee,$tuitionFee,$applyFeesStatus,$sesbatch],
      "params" => "isissssssss"
      ];
  
$insert = insert_user_data($data);
      
    }
     
  }
 
   $endDetails = [
      "status" => "success",
      "error" =>  "None",
      "scores" => $modifiedScores,
      "scoreable" => $examScoreable,
      "grade" => $grade,
      "remark" => $remark,
     "timespent" => $timespent
      ];  
  
  return $endDetails;   
     
 }   
    
}
 else{
     
        
  $endDetails = [
      "status" => "failed",
      "error" => "No records found for your written exam on $examCores",
      "scores" => "",
      "timespent" => ""
      ];  
  
  return $endDetails;   
         
   }
 
}

function correct_fees_db($era_db){
global $defaultAdmin;
     
if(isset($_SESSION["std_id"])){
 // the user is a std   
    
 $Id = $_SESSION["std_id"];  
 $cat = $_SESSION["std_cat"];
  
}
 elseif(isset($_SESSION["admin_id"])){
     
  $Id = $_SESSION["admin_id"];  
  $cat = $_SESSION["admin_cat"];
     
 } 


 if(isset($Id) && isset($cat)){
  if(check_exist($era_db,"Fees","Std_ID",$Id,"i")){
 
 $det = collect_user_data($era_db,"Fees","Std_ID",$Id,"i");
 $CAT = $det["Std_Cat"];
 
 if(!$CAT){
     
  if(update_user_data($era_db,"Fees","Std_Cat","Std_ID",$cat,$Id,"si")){
   $upd++;  
    
     }
    }
 
 //update apply_date
 $Allapply = collect_table_data($era_db,"Fees","ASC","Course");
 
 foreach ($Allapply as $applyCores){
 
  if(check_exist2($era_db,"Fees","Std_ID","Course",$Id,$applyCores,"is")){
   
   $applyDet = collect_user_data2($era_db,"Fees","Std_ID","course",$Id,$applyCores,"is");
    $applyDate = $applyDet["Apply_Date"]; 
    $applyfee = $applyDet["Apply_Fee"];

  if(!$applyDate){
   //get Apply_Date for this std & this course from the ref db   
 $RefDets = collect_table_data2($era_db,"Reference","Std_ID","Course",$Id,$applyCores,"is");   
  
  foreach ($RefDets as $RefDet){
  
  $ref = $RefDet["Reference_No"];
  $Date = $RefDet["Timestamp"];
  $Amt = $RefDet["Amount"];
      
  $exp = explode("_",$ref);
  $index = count($exp) -1;
  $str = strtolower($exp[$index]);
   if($str == "app" && $Amt == $applyfee){
  //update the apply date now
   if(update_user_data2($era_db,"Fees","Apply_Date","Std_ID","Course",$Date,$Id,$applyCores,"sis")){
   $upd++;  
    
     } 
     
      }
      
       }

   
      }
     }  

    }
  }
     
 }
 
 if($upd){
 return true;    
     
 }
 else{
     
     return false;
 }
}

function re_take_exam($era_db, $exam_Id,$std_id){
global $defaultAdmin;
     
$examDet = collect_user_data($era_db,"Exams","id", $exam_Id,"i");

 $ExamStatus = $examDet["Exam_Status"];  
 $examCores  = $examDet["Course"];
 $examOwner  = $examDet["Std_ID"];
 $examOwnerCat  = $examDet["Std_Cat"];
 $IniExamStatus = $examDet["Exam_Status"];
 $iniRetake = $examDet["Re_Take"];
$NewExamStatus = "Pending";
$newRetake = "true";


 if($std_id == $examOwner) {
 if($IniExamStatus == "Done"){
  
 if($iniRetake == "false"){
 // user have not retake exam before
 
  if(update_user_data($era_db,"Exams","Exam_Status","id",$NewExamStatus,$exam_Id,"si")){    
  
  update_user_data($era_db,"Exams","Total_Points","id","Pending",$exam_Id,"si"); // set exam Points back to Pending
   
  update_user_data($era_db,"Exams","Re_Take","id",$newRetake,$exam_Id,"si"); //limit retake chances
      
  //clear Exam_History 
   
   delete_data3($era_db,"Exam_History","Std_ID","Std_Cat","Course",$examOwner,$examOwnerCat,$examCores,"iss");
   
    $_SESSION["success_msg"] = "You have successfully Reversed your written exam  on $examCores, You may now proceed to Re-take the exam"; 
 
  $exec = true;
  
   }
   else{
       
 $_SESSION["error_msg"] = "Unable to perform your Request <br>
 Reasons: Error executing Database Query";  
    }
     
 }
  
else{
    
  $_SESSION["error_msg"] = "Unable to perform your Request.<br>
  Reasons: You have already Re-taken this exam before, please consult your tutor for assistance";
    
    
    }
  }   
  else{
       
   $_SESSION["error_msg"] = "Unable to perform your Request.<br>
  Reasons: Exam not yet taken";
       
   }  
 }
 else{
     
  $_SESSION["error_msg"] = "Request not performed.<br>
  Reasons: This Exam does not belongs to you.";
     
 }
 
 
 if(isset($exec)){
     
  echo '<script>
   window.location = "exams?schd_status=Pending";
   </script>';
     
    exit();    
     
 }
  else{
      
  echo '<script>
   window.location = document.referrer;
   </script>';
     
    exit();     
      
  }
    
} 


function  view_this_result($home_db,$era_db, $exam_Id,$std_id,$userCat,$DayDateTime){
global $defaultAdmin;
 
echo '<section class="section" id="about">
 <h2>Exam Details</h2>
 <span id="day"><strong>Today\'s Date: '.$DayDateTime.'</strong></span>';
   
$exam = collect_user_data($era_db,"Exams","id", $exam_Id,"i");

 $ExamStatus = $exam["Exam_Status"];  
 $examCores  = $exam["Course"];
 $examOwner  = $exam["Std_ID"];
 $examOwnerCat  = $exam["Std_Cat"];
  $exam_schd = $exam["Exam_Schedule"];
  $qst_num = (int)$exam["Qst_Num"];
  $duration = $exam["Exam_Duration"];
  $AssPoints = $exam["Assignment_Points"];
  $ExamPoints = $exam["Exam_Points"];
  $totalPoints = $exam["Total_Points"];
  $ExamStatus = $exam["Exam_Status"];
  $examFee = $exam["Exam_Fee"];
 $examFeeStatus =$exam["Exam_Fee_Status"];
 $qst_ans = $exam["Qst_Answered"];
 $timespent = $exam["Time_Spent"];
  $remark = $exam["Tutors_Remark"];
  $Date_taken = $exam["Date_Taken"];
   $grade = $exam["Grade"];
  $certificate = $exam["Certificate"];
  
  if($examOwnerCat == "Developer"){
      
   $conn = $home_db;
   $table = "Admins";
   $id_col = "Admin_ID";
      
  }
  else{
      
   $conn = $era_db;
   $table = "Students";
   $id_col = "Std_ID";
          
  }
  
 $Det = collect_user_data($conn,$table,$id_col,$examOwner,"i");
$name = $Det["SurName"]." ".$Det["OtherNames"];
  
      
 $qst_range = getConsecutiveNumbers(1,$qst_num);
    
  if(is_array($qst_range)){
      
  if(check_exist3($era_db,"Exam_History","Std_ID","Std_Cat","Course",$examOwner,$examOwnerCat,$examCores,"iss")){
  
foreach ($qst_range as $qstNo){
  
 $data = collect_user_data4($era_db,"Exam_History","Std_ID","Std_Cat","Course","Qst_Num",$examOwner,$examOwnerCat,$examCores,$qstNo,"issi"); 
 
 if($data){
     
 $selectedOption = $data["Option_Selected"];
 $correctOption = $data["Correct_Option"];
  $qst_Id = $data["Qst_ID"]; 
    
  $Qstdet = collect_user_data($era_db,"Questions","id",$qst_Id,"i");  
  $Qst = $Qstdet["Question"];
  $a = $Qstdet["A"];
  $b = $Qstdet["B"];
  $c = $Qstdet["C"];
  $d = $Qstdet["D"];
  $Ans = $Qstdet["Answer"];
 
 if($selectedOption == $correctOption){
     
  $marktype = "✓";  
  $idtype = "green-mark";
 }
 else{
     $marktype = "X";
     $idtype = "red-mark";
 }
    
if($selectedOption == "A"){
    
  $sel1 = "selected"; $mark1 = $marktype;
   $sel2 = ""; $mark2 = "";
   $sel3 = "";$mark3 = "";
   $sel4 = "";$mark4 = "";
  
   
}
elseif($selectedOption == "B"){
    
   $sel1 = "";  $mark1 = "";
   $sel2 = "selected";$mark2 = $marktype;
   $sel3 = "";$mark3 = "";
   $sel4 = "";$mark4 = "";
   
}
elseif($selectedOption == "C"){
    
   $sel1 = ""; $mark1 = ""; 
   $sel2 = "";$mark2 = "";
   $sel3 = "selected";$mark3 = $marktype;
   $sel4 = "";$mark4 = "";
  
}
elseif($selectedOption == "D"){
    
   $sel1 = "";  $mark1 = "";
   $sel2 = "";$mark2 = "";
   $sel3 = "";$mark3 = "";
   $sel4 = "selected";$mark4 = $marktype;
    
}


echo '<div class="exam-box" id="exam-box">

  <div id="question-text" style="margin: 15px 0;">Q'.$qstNo.': '.$Qst.'</div>

  <div id="options-container">
   
  <button class="option-btn '.$sel1.'">A. '.$a.' <span id="'.$idtype.'">'.$mark1.'</span></button>
  <button class="option-btn  '.$sel2.'">B. '.$b.' <span id="'.$idtype.'">'.$mark2.'</span></button>
   <button class="option-btn  '.$sel3.'">C. '.$c.' <span id="'.$idtype.'">'.$mark3.'</span></button>
    <button class="option-btn  '.$sel4.'">D. '.$d.' <span id="'.$idtype.'">'.$mark4.'</span></button>
    </div>
  <br>
</div>'; 
    
     
    }
  
  }

   
      
  }
  
  else{
      
     echo '<p>
 <br><center><i id="warning" class= "fas fa-exclamation-triangle"></i><br>No exam record found for '.$examCores.' </center></p><hr>';  
       
      
    }
  
  }
  else{
      
   echo '<p>
 <br><center><i id="warning" class= "fas fa-exclamation-triangle"></i><br>Error loading Exam Details</center></p><hr>';  
    
      
  }
  
  
  if($userCat == $examOwnerCat && $std_id == $examOwner){
  if($certificate){
      
 $dir = "results?show_certi_ficate&exam_id=$exam_Id&std_id=$examOwner";
  $btn = "Show Certificate";
  addBtn($btn,$dir);    
      
      
  }
  
  else{
 $dir = "results?get_certi_ficate&exam_id=$exam_Id&std_id=$examOwner";
  $btn = "Get Certificate";
  addBtn($btn,$dir);
    
      
   }
  }
  else{
   
   $dir = "results?show_certi_ficate&exam_id=$exam_Id&std_id=$examOwner";
  $btn = "Show Certificate";
  addBtn($btn,$dir);   
      
  }
  
  echo '</section>';
}

function getConsecutiveNumbers($first, $last) {
  if (!is_int($first) || !is_int($last)) {
        return "Both inputs must be integers.";
    }
    
    elseif($first == $last){
        
     return "First and last number must not be the same.";   
        
    }
    else{
        
   
    if($first > $last) {
   // descending order       
          
      return range($first, $last, -1);   
      
       }
    
    else{
     // ascending order
     return range($first, $last);
        
      }
    }

}

function get_certi_ficate($home_db,$era_db,$userCat,$std_id,$exam_Id){
    
 global $defaultAdmin,$cutoffMark;
 
 if($exam_Id && $std_id){
 
 $examDet = collect_user_data($era_db,"Exams","id", $exam_Id,"i");
 $total_points = $examDet["Total_Points"];
 $ExamStatus = $examDet["Exam_Status"];  
 $examCores  = $examDet["Course"];
 $examOwner  = $examDet["Std_ID"];
 $examOwnerCat  = $examDet["Std_Cat"];
 $certificate  = $examDet["Certificate"];
 $cert_fee  = $examDet["Certificate_Fee"];

 if($ExamStatus == "Done"){
     
if($examOwner == $std_id && $examOwnerCat == $userCat){
  // check cliteria for getting cert or to be done with the entire course. 

 if($total_points >= $cutoffMark){
 
 $coresdet = collect_user_data3($era_db,"Fees","Std_ID","Std_Cat","Course",$std_id,$userCat,$examCores,"iss");   
 $courseStatus = $coresdet["Course_Status"];
 
 if($courseStatus == "Done"){
     
 if($cert_fee == "Paid"){
 
 if($certificate){
  // certificate had been generated already
 echo '<input type="hidden" id="std-id" value="'.$std_id.'">
<input type="hidden" id="exam-id" value="'.$exam_Id.'">';

   echo '<script>
   var stdId = document.getElementById("std-id").value;
   var ExamId = document.getElementById("exam-id").value;
   var msg = "Certificate already generated";
   
   window.location = `results?show_certi_ficate&exam_id=${ExamId}&std_id=${stdId}&msg_report=${msg}&report=suc`;
   </script>';
     
    exit();     
       
 }
 else{
 // all conditions satisfied, now generate certificate
global $cert_ext;
$cert_Id = generate_id(10);

while(check_exist($era_db,"Exams","Certificate",$cert_Id,'s')){

 $cert_Id = generate_id(10);
   
}
 
$path = $_SERVER["DOCUMENT_ROOT"];

$cert_sample1 = "certificates/samples/cert_sample1.png"; 
$cert_sample2 = "certificates/samples/cert_sample2.png"; 

$cert_template1 = "certificates/templates/cert_template1.png"; 
$cert_template2 = "certificates/templates/cert_template2.png"; 


echo '<section class="section" id="about">
 <h2>Please Select a Template for your Certificate</h2>';
 
if(file_exists($path.'/'.$cert_sample1)){
 $temp++;   
 
echo '<div class="temp">
<a href="/'.$cert_sample1.'"><img src="/'.$cert_sample1.'" alt="Template 1"></a></div>';

$_SESSION["cert_id"] = $cert_Id;
$_SESSION["exam_id"] = $exam_Id;

$btn = "Use this Template";
$dir = "includes/generate_cert?std_id=$std_id&template=$cert_template1&templateNo=1";


 addBtn($btn,$dir,"adbtn1");  

echo '<div id="spinner"></div>
<small id="prep_cert1">Preparing Certificate, Please wait ...</small>';

    
}

if(file_exists($path.'/'.$cert_sample2)){
 $temp++;   
 
 echo '<div class="temp">
 <br><hr><br>
 <a href="/'.$cert_sample2.'"><img src="/'.$cert_sample2.'" alt="Template 2"></a></div>';

$_SESSION["cert_id"] = $cert_Id;
$_SESSION["exam_id"] = $exam_Id;

$btn = "Use this Template";
$dir = "includes/generate_cert?std_id=$std_id&template=$cert_template2&templateNo=2";

addBtn($btn,$dir,"adbtn2");  

echo '<div id="spinner2"></div>
<small id="prep_cert2">Preparing Certificate, Please wait ...</small>';

  }

if(!$temp){
    
echo '
<p>
Sorry certificates cannot be generated at the moment. We are working tirelessly to make it happen. Please check back later
</p>';

$btn = "Back";
$dir = "results";
addBtn($btn,$dir);  
    
 }

echo '</section> 
 <style>
 .section h2{
     font-size:24px;
 }
 
 .temp img{
 display:block;
 width:100%;
 height:210px;
 margin:auto;  
 border: 1px solid #ddd;
 border-radius:10px;  
 box-shadow: 1px 2px 8px rgba(100,0,0,0.5) 
 }
 #prep_cert1, #prep_cert2{
     display:none;
     text-align:center;
     color:rgb(50,200,50);
     font-size:10px;
     position:relative;
     top:1px;
     font-weight:bold;
 }
 </style>
 <script>
 var link1 = document.getElementById("adbtn1");

 var link2 = document.getElementById("adbtn2");

 var Spinner1 = document.getElementById("spinner");
  var prep1 = document.getElementById("prep_cert1");

 var Spinner2 = document.getElementById("spinner2");
  var prep2 = document.getElementById("prep_cert2");
 
 
 link1.addEventListener("click",()=>{
   
  Spinner1.style.display = "flex";
  prep1.style.display = "block";
  Spinner2.style.display = "none";
  prep2.style.display = "none";

 });

  link2.addEventListener("click",()=>{
 
  Spinner1.style.display = "none";
  prep1.style.display = "none";

 Spinner2.style.display = "flex";
  prep2.style.display = "block";


 });
 
 </script>';  
  
  }
 }
  else{
 //certificate fee has not been paid 
 
  require $_SERVER["DOCUMENT_ROOT"].'/date_time.php';
  $fees = collect_user_data($era_db,"Fees_Settings","Course",$examCores,"s");
  $cert_feeAmt = $fees["Certificate_Fee"];
  $service = "Certificate fee for $examCores"; 
 
 $userDet = collect_user_data($era_db,"Students","Std_ID",$std_id,"i");
 $email = $userDet["Email"];
   
 if(!$email){
 //check 2nd db    
  $userDet = collect_user_data($home_db,"Admins","Admin_ID",$std_id,"i");
 $email = $userDet["Email"];
    
 }  
   
   $limit = 1000; 
   $feetype = "ctf";    
   $fee_ref = generate_feeRef($feetype);    
  while($limit && check_exist($era_db,'Reference','Reference_No',$fee_ref,'s')){
      
   $fee_ref = generate_feeRef($feetype); 
   $limit--;
  }
  
 if(!$limit){
 //could not get a unique Reference
     $fee_ref = 'ref_tut_'.time().'_ctf';
 }
  
  $data = [
      "conn" => $era_db,
      "table" => "Reference",
      "cols" => ['Timestamp','Std_ID','Reference_No','Amount','Service','Course'],
      "vals" => [$Date,$std_id,$fee_ref,$cert_feeAmt,$service,$examCores],
      "params" => "sissss"
      
      ];
   
 if(check_exist2($era_db,"Reference","Std_ID","Service",$std_id,$service,"is")){
 //update records    
  if(update_user_data2($era_db,"Reference","Reference_No","Std_ID","Service",$fee_ref,$std_id,$service,"sis")){
   
   $insert = [
       "status" => "success",
       "error" => "None"
       ];   
   }
   else{
    
       $insert = [
       "status" => "failed",
       "error" => "unable to execute Database query"
       ]; 
   }
     
 }
 
 else{
  //new insert records    
 $insert = insert_user_data($data);

 }
  
 if($insert["status"] =="success"){
 
 $_SESSION["apply_email"] = $email;
 $_SESSION["apply_course"] = $examCores;
 $_SESSION["apply_service"] = $service;
 $_SESSION["apply_ref"]  = $fee_ref;   
 
 $_SESSION["success_msg"]  = "Please review your payment details for $examCores certificate and click on 'Pay Now' to make payment. Once your payment is verified, You will get your certificate";
 
echo '<input type="hidden" id="service" value="'.$service.'">
<input type="hidden" id="email" value="'.$email.'">
<input type="hidden" id="coresname" value="'.$examCores.'">';

   echo '<script>
   var Serve = document.getElementById("service").value;
   var Email = document.getElementById("email").value;
   var coresName = document.getElementById("coresname").value;
   
  window.location = `tut_fees?fees_type=pay_Now&service=${Serve}&email=${Email}&course_name=${coresName}`;
   </script>';
     
    exit();         
      
      
  }
  else{
      
  $_SESSION["error_msg"]  = "unable to initiate certificate fee payment, if this error persist, please consult the $Director via the contact form";
   
   echo '<script>
   window.location = "results";
   </script>';
     
    exit();     
      
   }   
  }
 }
   
 else{
     
  $_SESSION["error_msg"]  = "You are not yet done with the selected course and hence cannot get its certificate. However, if you disagree with this auto detection, please consult the $Director via the contact form";
   
   echo '<script>
   window.location = "results";
   </script>';
     
    exit();    
     
   }  
 }
 else{
     
    $_SESSION["error_msg"]  = 'You must have at least '.$cutoffMark.'%  total points in a course before you can get its certificate.
   Your total points is '.$total_points.'% and you need to re-take the exam. <br><em>Note:</em> You are  only allowed to re-take an exam once, if you are still unable to meet up with the cutoff mark then you need to consult you tutor to allow you go back to class and there after grant you the permission to re-take the exam again (Going back to class might incure payments)<br><br>
    <a id= "re_take" href="?re_take_exam&exam_id='.$exam_Id.'&std_id='.$examOwner.'">Re-Take '.$examCores.' Exam</a>';
   
   echo '<script>
   window.location = "results";
   </script>';
     
    exit();   
     
     
 } 
}
 else{
     
     $_SESSION["error_msg"]  = "This exam details does not belong to you and hence cannot get its certificate. However, if you disagree with this auto detection, please consult the $Director via the contact form";
   
   echo '<script>
   window.location = "results";
   </script>';
     
    exit();  
     
   }    
     
 }
 else{
     
   $_SESSION["error_msg"]  = "You must be done with exams for a course before you can get its certificate";
   
   echo '<script>
   window.location = "results";
   </script>';
     
    exit(); 
  }

 }
 else{
     
   $_SESSION["error_msg"]  = "Unable to generate certificate. <br>
   Re: Exam Id or User Id was not received";
   
   echo '<script>
   window.location = "results";
   </script>';
     
    exit();    
     
 }

 
}


function show_certi_ficate($home_db,$era_db,$userCat,$std_id,$exam_Id,$DayDateTime){
 global $defaultAdmin;
 
 $exam = collect_user_data($era_db,"Exams","id", $exam_Id,"i");

 $ExamStatus = $exam["Exam_Status"];  
 $examCores  = $exam["Course"];
 $examOwner  = $exam["Std_ID"];
 $examOwnerCat  = $exam["Std_Cat"];
 $certificate  = $exam["Certificate"];
 $date_issued = $exam["Date_Issued"];
 
 $owner = get_user_name();
 $ownerName = $owner["fullname"];
 $certFolder ="certificates";
 
  echo '<section class="section" id="about">
 <h2>'.$examCores.' Certificate for '.$ownerName.'</h2>';

 if($ExamStatus == "Done"){
     
 if($certificate){
     
// certificate file path
$certNamepdf = $examCores.'_'.$certificate.'.pdf';
$certNamepng = $examCores.'_'.$certificate.'.png';

$pdfFile = "$certFolder/$certNamepdf";
$pngFile = "$certFolder/$certNamepng";


if(file_exists($pngFile)){
    $certExist++;
//display Certificate here    
 echo '<div class="temp">
 <a href="/'.$pngFile.'"><img src="/'.$pngFile.'" alt="'.$examCores.' Certificate"></a></div><br><br>';
}
if(file_exists($pdfFile)){
   $certExist++;
   
echo '<div class="table_btn">
<a id="dwn_ass" href="downloader?dwn_path='.$certFolder.'&dwn_file='.$certNamepdf.'&unlink_file=false">Download Certificate</a>';

 global $url;
 $certLink = $url.'/'.$certFolder.'/?cert_id='.$certificate;

 $escapedLink = htmlspecialchars($certLink, ENT_QUOTES, 'UTF-8');
 
 if(isValidAndReachableUrl($escapedLink)){

echo '<a id="share_cert" href="#" onclick="shareCert(\'' . $escapedLink . '\',\''.$examCores.'\'); return false;">Share Certificate</a>';
  
 }

echo '</div>';

}

if(!$certExist){
  echo '<p>
 <br><center><i id="warning" class= "fas fa-exclamation-triangle"></i>
  <br>Certificate not found</center></p>';  
}
 
echo '<hr><span id="day"><strong>Current Date-Time: '.$DayDateTime.'</strong></span>

<div id="spinner"></div>
<small id="prep_cert1">Downloading Certificate, Please wait ...</small>

<style>
.table_btn{
   position:relative;
    bottom:10px;
   justify-content:center;
}
.table_btn a{
    
  width:50%;  
    
}
</style>
<script>
 var link = document.getElementById("dwn_ass");

 var Spinner = document.getElementById("spinner");
  var prep = document.getElementById("prep_cert1");


 link.addEventListener("click",()=>{
   
  Spinner.style.display = "flex";
  prep.style.display = "block";
  
 setTimeout(()=>{
 
  Spinner.style.display = "none";
  prep.style.display = "none";
    
 },5000); 
  
 });

 </script>';  

 }
 else{
     
  echo '<p>
 <br><center><i id="warning" class= "fas fa-exclamation-triangle"></i><br>No Certificate to show at the moment</center></p><hr>';  
  
    $dir ="results";
    $btn = "Back";
    addBtn($btn,$dir);  
 }    
     
}
 else{
     
  echo '<p>
 <br><center><i id="warning" class= "fas fa-exclamation-triangle"></i><br>Student not done with course contents</center></p><hr>';  
    
    $dir ="results";
    $btn = "Back";
    addBtn($btn,$dir);
 }
 
  echo '</section>';
    
    
}


function get_cert_Owner($home_db,$era_db,$std_id,$exam_Id){

if($std_id && $exam_Id){
 global $DayDateTime;
 $exam = collect_user_data2($era_db,"Exams","id", "Std_ID", $exam_Id,$std_id,"ii");

 $examCores  = $exam["Course"];
 $examOwner  = $exam["Std_ID"];
 $examOwnerCat  = $exam["Std_Cat"];
 $certificate  = $exam["Certificate"];
 $examDate =  $exam["Date_Taken"];
 $dateIssued = $DayDateTime;

//get owner's name 
 $stdsCats = collect_table_data($era_db,"Students","","Std_Cat");
 $adminsCats = collect_table_data($home_db,"Admins","","Admin_Cat");
  
 if($examOwnerCat && in_array($examOwnerCat,$stdsCats)){
     
 $stdDet =  collect_user_data($era_db,"Students", "Std_ID",$std_id,"i");  
 $ownerName = $stdDet["SurName"]." ".$stdDet["OtherNames"];
     
 } 
 elseif($examOwnerCat && in_array($examOwnerCat,$adminsCats)){
 $adminDet =  collect_user_data($home_db,"Admins", "Admin_ID",$std_id,"i");  
 $ownerName = $stdDet["SurName"]." ".$stdDet["OtherNames"];
  }
  else{
 //Unknown user_cat     
   $certOwner = [];  
 return $certOwner;   
       
  }
//get course-dur

$durInWeeks = estimate_course_duration($era_db,$examCores,"weeks");
$durInMonths = estimate_course_duration($era_db,$examCores,"months");
  
//get from-date i.e date of application

$applyDet = collect_user_data2($era_db,"Fees","Std_ID","Course",$std_id,$examCores,"is");  
 $applyDate = $applyDet["Apply_Date"];


 $FromDate = harmonize_apply_date($durInWeeks,$applyDate,$examDate,"harmonize");
     
  $certOwner = [
      "owner-name" => $ownerName,
      "course-dur" => $durInMonths,
      "course" => $examCores,
      "from-date" => $FromDate,
      "to-date" => $examDate,
      "date-issued" => $dateIssued,
      "cert-type" => "Certificate of Completion",
      ]; 
  
  return $certOwner;  
}

else{
  $certOwner = [];  
 return $certOwner;   
    
}

 

}

function harmonize_apply_date($duration,$applyDate,$examDate,$harmonize){
 
$exp = explode(" ",$duration);
$dur = $exp[0]; //in weeks

 if(!$dur || !is_numeric($dur)){
  //Default dur to 12 weeks (3 month)  
  $dur = 12; //in weeks
     
 }
 
 //convert dur to second
 $week = 60*60*24*7; //sec in 1 week
 $durSec = $week*$dur;
 
 if(!$examDate){
 
 $examDateSec = time(); // Current time in sec
     
 }
 else{
   
   if(strpos($examDate,'/')){
    
    $replace = str_replace('/','-',$examDate); 
  
  $examDateSec = strtotime($replace); // convert to time in sec  
       
   }
   
 }
 
 if(!$applyDate){
 
 $applySec = $examDateSec; // set to dateIssued and back date if harmonize is passed
     
 }
 else{
   
   if(strpos($applyDate,'/')){
    
    $replace = str_replace('/','-',$applyDate); 
  
  $applySec = strtotime($replace);  //convert to time in sec  
       
   }
   
 } 

$harmonize = strtolower($harmonize);
if($harmonize == "harmonize"){

$Diff = $examDateSec - $applySec;
$weekDiff = floor($Diff/$week);

if($dur >= 20){
 // 5 months course or more 
   $allowance = 4;//4 weeks allowance
    
}
elseif($dur >= 12){
  // 3 or 4 months course  
   $allowance = 2;//2 weeks allowance 

}
else{
 $allowance = 1; //1 week allowance
    
}


if($weekDiff == $allowance){

 $FromDate = date("D d/m/Y h:i A",$applySec);

return $FromDate;   
}
else{
  
//back date Apply_Date
$backTime = $examDateSec - $durSec;

$FromDate = date("D d/m/Y h:i A",$backTime);

return $FromDate;   
    
    
 }
}
else{
    
 $FromDate = date("D d/m/Y h:i A",$applySec);

return $FromDate;   

 }

}

function convert_date($date){
    
// $date = "Mon 05/01/2025 10:25 PM";  
// coverted format  = 5th Jan, 2025
 
    // Normalize delimiters
  if(strpos($date,"/")){
  $date = str_replace("/", "-", $date);
  
  }
   
    // Try to create DateTime object
    try {
        $dt = new DateTime($date);
    } catch (Exception $e) {
        return "Invalid date format";
    }

    if(!$dt) return "Invalid date format";

    // Extract parts
    $day   = (int)$dt->format("j");
    $month = $dt->format("M");
    $year  = $dt->format("Y");

    // Ordinal suffix
    if ($day % 10 == 1 && $day != 11) $suffix = "st";
    elseif ($day % 10 == 2 && $day != 12) $suffix = "nd";
    elseif ($day % 10 == 3 && $day != 13) $suffix = "rd";
    else $suffix = "th";

    return $day . $suffix . " " . $month . ", " . $year;

}

function date_time_convert($date){
 global $DayDateTime;   
 
 $todaystrtoTime = strtotime(str_replace('/','-',$DayDateTime));
  
 if($date){
  // Normalize delimiters
  if(strpos($date,"/")){
  $date = str_replace("/", "-", $date);
  
  }
 
 $DateObj = new DateTime($date);
 $convDate = $DateObj->format('D d/m/Y h:i A');
 $convDayDate = $DateObj->format('D d/m/Y');
  
 $strtoTime = strtotime(str_replace('/','-',$convDate));
 
if(!$strtoTime){
 $strtoTime = 0;   
}
if(!$todaystrtoTime){
  $todaystrtoTime = 0; 
}
   
$convert = [
     "convdate" => $convDate,
     "convdaydate" => $convDayDate,
     "strtoTime" => $strtoTime,
     "todaystrtoTime" => $todaystrtoTime,
     ];  
    
 }
 else{
     
  $convert = [
     "convdate" => "",
     "convdaydate" => "",
     "strtoTime" => 0,
     "todaystrtoTime" => $todaystrtoTime,
     ];  
     
 }
 
  return $convert;  
    
}


function romve_exam_cert($era_db,$exam_Id,$std_Id,$tutor_Id){
global $defaultAdmin;
    
 if(isset($_SESSION["remove_cert_init"])){
     
  $init = $_SESSION["remove_cert_init"];
  $admin_cat = $_SESSION["admin_cat"];
  
 if($init == "truely-truely" && $admin_cat == $defaultAdmin ){
  
  $examDet = collect_user_data($era_db,"Exams","id",$exam_Id,"i");   
 $examOwner = $examDet["Std_ID"];
 $examOwnerCat = $examDet["Std_Cat"];
 $examCores = $examDet["Course"];
 $certificate = $examDet["Certificate"];

  if($std_Id == $examOwner){
   
   if($certificate && is_numeric($certificate)){

  $certpng = $_SERVER["DOCUMENT_ROOT"].'/certificates/'.$examCores.'_'.$certificate.'.png';
  $certpdf  = $_SERVER["DOCUMENT_ROOT"].'/certificates/'.$examCores.'_'.$certificate.'.pdf';
  
   //set certificate column to nul in db
  $certColumn = null;
  
  if(update_user_data2($era_db,"Exams","Certificate","id","Std_ID",$certColumn,$exam_Id,$examOwner,"sii")){
  
  if(file_exists($certpng)){
      
   unlink($certpng);  
      
  }
  
  if(file_exists($certpdf)){
      
   unlink($certpdf);  
      
  }     
   
  echo '<script>
 
 window.location.href = "exam_manager?view_exam_schedule&schd_status=Done&showToast=Certificate removed successfully";
 </script>';
 
 exit();   
      
      
  }
  else{
      
          
    echo '<script>
 
 alert("Unable to remove Certificate ! Error: Error executing Database query");
 
 window.location.href = "exam_manager?view_exam_schedule&schd_status=Done";
 </script>';
 
 exit();    
      
     }
   } 
   else{
       
    echo '<script>
 
 alert("This Exam has no Certificate !");
 
 window.location.href = "exam_manager?view_exam_schedule&schd_status=Done";
 </script>';
 
 exit();      
      
   }   
  }
  else{
      
    //suspicious
 
 echo '<script>
 
 alert("Suspicious attempts! Stop this request else you will be blocked from assessing this site");
 
 window.location.href = document.referrer;
 </script>';
 
 exit();      
      
      
   }
      
  }
  
  else{
      
    //suspicious
 
 echo '<script>
 
 alert("Suspicious attempts! Stop this request else you will be blocked from assessing this site");
 
 window.location.href = document.referrer;
 </script>';
 
 exit();     
      
  }  
 }
 else{
 //suspicious
 
 echo '<script>
 
 alert("Suspicious attempts! Stop this request else you will be blocked from assessing this site");
 
 window.location.href = document.referrer;
 </script>';
 
 exit();    
     
 }
    
    
}