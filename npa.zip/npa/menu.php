<?php

echo '<div class="back">
<a id ="back-link" href="/home" title="Back to home page">
<i class="fa-solid fa-arrow-left"></i>
 </a></div>';

echo '<style>
.back{
    display:block;
    position: relative;
    top:15px;
    margin-left:5%;
   height:10px;
   width:50px;

}

.back a{
    text-decoration:none;
    color:#333;
    cursor:pointer;
    z-index:10;
    
}

.back a:hover{
    
    transition: 0.3s ease;
    scale: 1.5;
    color:#f8f8;
    font-weight:bold;
    font-size:20px;
}

</style>';
