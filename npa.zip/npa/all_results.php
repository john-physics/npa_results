<?php

if(isset($_SESSION["staff_cat"])){
  
  $staffCat = $_SESSION["staff_cat"];
  if(isset($authorized) && is_array($authorized)){
   
   if(!in_array($staffCat, $authorized)){
    
    $_SESSION["error_msg"] ="Sorry you are not authorized to view All Results on this system";
  echo '<script>
 window.location.href ="/home?msg_report=Access denied!&report=failed";
 
 </script>';   
  
  exit();          
       
   }   
  }
  else{
      
 $_SESSION["error_msg"] ="Some important configuration constants are missing and hence access to Result Database cannot be granted. please consult the developer of this system to fix the missing constants";
 
  echo '<script>
 window.location.href ="/home?msg_report=missing configuration constants!&report=failed";
 
 </script>';   
  
  exit();       
      
  }
}
else{
 
 echo '<script>
 window.location.href ="/home?msg_report=please login to continue!&report=failed";
 
 </script>';   
  
  exit();  
 }
?>


<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, Helvetica, sans-serif;
}

body{
    background:#efefef;
  /*  padding:30px 15px 60px; */
    color:#333;
}

/* ================= TITLE ================= */

.page-title{
    text-align:center;
    margin-top:10px;
}

.page-title h1{
    font-size:40px;
    color:#005f63;
    font-weight:700;
}

.title-line{
    width:80%;
    height:14px;
    margin:auto;
    border-radius:20px;

    background:linear-gradient(
        to right,
        rgba(0,95,99,0),
        rgba(0,95,99,0.95),
        rgba(0,95,99,0)
    );
}

/* ================= FILTER CARD ================= */

.filter-card{
    width:90%;
    margin:50px auto 35px;
    background:#fff;
    border-radius:20px;
    padding:20px 30px;
    box-shadow:0 2px 10px rgba(0,0,0,0.08);
   
    
}

.filter-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
    gap:30px 40px;
}

.filter-group label{
    display:block;
    font-size:18px;
    margin-bottom:10px;
    color:#444;
}

.filter-group select{
    width:100%;
    height:50px;
    border:2px solid #d8d8d8;
    border-radius:10px;
    font-size:16px;
    padding:0 5px;
    outline:none;
    background:#fff;
    color:#333;
}

.filter-group select:focus{
    border-color:#2b78b7;
    box-shadow:0 0 0 3px rgba(43,120,183,0.1);
}

/* ================= TOTAL FOUND ================= */

.total-found{
    text-align:center;
    margin:20px 0 25px;
    font-size:20px;
    font-weight:600;
    color:#555;
}

/* ================= TABLE ================= */

.table-wrapper{
    display: block;
    width:100%;
    overflow:auto;
    padding: 0 1px;
    border-radius: 20px;
}

.results-table{
    width:100%;
    border-collapse:collapse;
    background:#fff;
    border-radius: 20px;
}

.results-table thead{
    background:#00bf4f;
    
}

.results-table th{
    color:#fff;
    padding:10px 8px;
    font-size:14px;
    font-weight:600;
   border:1px solid rgba(255,255,255,0.15);
    text-align:center;
      background:#00bf4f;
    
}

.results-table td{
    padding:5px 8px;
    border:1px solid #e5e5e5;
    text-align:center;
    font-size:12px;
    vertical-align:middle;
    background:#fff;
    
}

.results-table td:nth-child(3){
    
  width: 200px;  
    
}
.results-table tbody tr:hover{
    background:#fafafa;
}

.student-photo{
    width:80px;
    height:80px;
    object-fit:cover;
    border-radius: 10px;
}

.student-name{
    text-align:left;
    font-weight:600;
    line-height:1.2;
}

.na{
    color:red;
    font-weight:bold;
}

/* ================= ACTION MENU ================= */

.action-area{
    position:relative;
}

.menu-btn{
    width:50px;
    height:50px;
    border-radius:10px;
    border:2px solid #7eb4db;
    background:#fff;
    cursor:pointer;
    font-size:24px;
    color:#2c7fb7;
}

.menu-btn:hover{
    background:#f1f9ff;
}

.action-menu{
    position:absolute;
    top:0;
    right:10%; 
    background:#fff;
    border-radius:10px;
    box-shadow:0 5px 15px rgba(0,0,0,0.15);
    padding:8px;
    display:none;

    flex-direction:row;
    gap:10px;
    z-index:100;
}

.action-menu form{
    margin:0;
}

.action-menu button{
    width:40px;
    height:40px;
    border:none;
    border-radius:8px;
    cursor:pointer;
    color:#fff;
    font-size:14px;
}

.view-btn{
    background:#00a651;
}

.edit-btn{
    background:#2b78b7;
}

.view-btn:hover{
    opacity:0.9;
}

.edit-btn:hover{
    opacity:0.9;
}

.filter-btn button{
  display: block; 
  position: relative;
  top:20px;
  width: 80%;
  padding: 10px;
  border:none;
  color: #fff;
  
  background:linear-gradient(
        to right,
        rgba(0,100,90,0.5),
        rgba(50,100,80,0.85),
        rgba(0,100,90,0.5)
    );
    
 
    
margin: auto;
text-align: center;
font-size: 14px;
font-weight: bold;
margin-bottom: 15px;
border-radius: 10px;
cursor: pointer;
}
/* ================= MOBILE ================= */

@media screen and (min-width:800px){

    .page-title h1{
        font-size:42px;
    }

    .title-line{
        width:60%;
    }

    .filter-card{
        padding:35px 25px;
    }

    .filter-group label{
        font-size:20px;
    }

    .filter-group select{
        height:70px;
        font-size:22px;
    }

    .results-table th,
    .results-table td{
        font-size:18px;
    }

}

</style>
</head>
<body>

<!-- ================= TITLE ================= -->

<div class="page-title">
    <h1>All Results</h1>
    <div class="title-line"></div>
</div>

<!-- ================= FILTER FORM ================= -->

<form action="" method="post" class="filter-card">

    <div class="filter-grid">

        <div class="filter-group">
            <label>Select Class:</label>

    <select name="class">
      
     <?php
 $classes = sortClasses(collect_table_data1($conn,"variables","type","Class","s","","value"));
 
 
 $mergeValue = [$viewClass,"All"];
 
 $classes = merge_into_array($mergeValue,$classes,"front",false);
 foreach ($classes as $classOption){
     
  echo '<option>'.$classOption.'</option>'; 
 }

   ?>
         </select>
        </div>

        <div class="filter-group">
            <label>Select Exam:</label>

        <select name="term">
     <?php
     
 $terms = generate_terms();
  $mergeValue = [$term,"All"];
 $terms = merge_into_array($mergeValue,$terms,"front",false);
 
foreach($terms as $termOption){

 if($termOption == "All"){
     $exam = "Examinations";
 }
 else{
   $exam = "Examination";   
 }

echo '<option value="'.$termOption.'">'.$termOption.' '.$exam.'</option>';
}
     
 ?>
           
      </select>
        </div>

        <div class="filter-group">
            <label>Select Group:</label>

          <select name="group">
      <?php
   $groups = collect_table_data1($conn,"variables","type","Class","s","","classification");
 $mergeValue = [$group,"All"];
 $groups = merge_into_array($mergeValue,$groups,"front",false);
   
   foreach ($groups as $groupOption){
    
echo '<option value="'.$groupOption.'">'.$groupOption.'</option>'; 
       
   }
      
  ?>
          
     </select>
        </div>

  <div class="filter-group">
            <label>Select Year:</label>
     <select name="session">
    <?php
    
 $sessions = generate_sessions();
 $sessions = merge_into_array($session,$sessions,"front",false);
foreach($sessions as $sessionOption){

echo '<option>'.$sessionOption.'</option>';

}  
  ?>
  
 </select>
        </div>
 </div>
    
 <div class="filter-btn">
    <button type ="submit" id="submit-filter" name="submit-filter-results">Filter Results</button>
    </div>

</form>

<!-- ================= TOTAL FOUND ================= -->
<?php

$Allresults = [];
$table = form_table_name("results_",$session);

if(check_exist_table($conn,$table)){
    
  if($viewClass =="All" && $group == "All"){
    
 $Allresults = collect_table_data($conn,$table,"id DESC","*");   

}
elseif($viewClass == "All" && $term =="All"){
    
 $Allresults = collect_table_data($conn,$table,"id DESC","*");   

}
elseif($viewClass == "All" && $term !="All"){
    
$Allresults = collect_table_data1($conn,$table,"term",$term,"s","id DESC","*");
    
}

elseif($viewClass !== "All" && $term =="All"){
    
$Allresults = collect_table_data1($conn,$table,"term",$term,"s","id DESC","*");
    
}
else{
  //Filter display
  
 $Allresults = collect_table_data2($conn,$table,"term","class",$term,$viewClass,"ss","id DESC","*");

 }  
}

$totalResults = count($Allresults);
if($term == "All"){
    
    $term_session = $session;
}
else{
    $term_session = $term." ".$session;
}


echo '<div class="total-found">
    <p>Showing '.$viewClass.' Results for '.$term_session.'</p>';
    
 if($totalResults){
   echo '<p>Total <span id="total-found">'.number_format($totalResults).'</span> data found</p>';  
      
  }
    
echo '</div>


<div class="table-wrapper">
<table class="results-table">
<thead>
<tr>
    <th>S/N</th>
    <th>Photos</th>
    <th>Name</th>
    <th>PIN</th>
    <th>Class</th>
    <th>Group</th>
    <th>Exam</th>
    <th>Year</th>
    <th>Action</th>
</tr>
</thead>
<tbody>';

 if($Allresults && is_array($Allresults)){
  $sn = 0;
 foreach ($Allresults as $result){
  $sn++;   
  $std_id = $result["std_id"];   
  $group = $result["std_cat"];
  $std_class = $result["class"];
  //get std details
  $std_details = collect_user_data($conn,"students","std_id",$std_id,"i");
  $std_name = $std_details["surname"]." ".$std_details["othernames"];
  $std_pin = $std_details["std_pin"];
  $profile = $std_details["profile"];
  
   
   echo '
   <tr>
    <td>'.$sn.'</td>
    <td>
    <img src="images/students/'.$profile.'"
        class="student-photo">
    </td>
    <td class="student-name">'.$std_name.'</td>
    <td>'.$std_pin.'</td>
    <td>'.$std_class.'</td>
    <td>'.$group.'</td>
    <td>'.$term.'</td>
    <td>'.$session.'</td>
    <td class="action-area">

       <button type="button"
        class="menu-btn"
        onclick="toggleMenu(this)">
            <i class="fas fa-bars"></i>
        </button>

        <div class="action-menu">

            <!-- VIEW FORM -->
            <form action="/results" method="POST">

              <input type="hidden"
                name="std_id"
                value="'.$std_id.'">
           
              <input type="hidden"
                name="std_pin"
                value="'.$std_pin.'">
              
              <input type="hidden"
                name="std_class"
                value="'.$std_class.'">

              <input type="hidden"
                name="term"
                value="'.$term.'">

             <input type="hidden"
                name="session"
                value="'.$session.'">

                <button type="submit"
                class="view-btn"
                title="View">
                    <i class="fas fa-eye"></i>
                </button>

            </form>

            <!-- EDIT FORM -->
            <form action="/edit_results" method="POST">
 
            <input type="hidden"
                name="std_id"
                value="'.$std_id.'">
           
              <input type="hidden"
                name="std_pin"
                value="'.$std_pin.'">
              
              <input type="hidden"
                name="std_class"
                value="'.$std_class.'">

              <input type="hidden"
                name="term"
                value="'.$term.'">

             <input type="hidden"
                name="session"
                value="'.$session.'">

                <button type="submit"
                class="edit-btn"
                title="Edit">
                    <i class="fas fa-pen"></i>
                </button>

            </form>

        </div>

    </td>

</tr>'; 
     
  }
 }
 else{
  
  echo '<tr>
  <td colspan="9">No data found!</td>
  
  </tr>';   
     
 }

echo '</tbody>

</table>
</div>';


?>

<script>

function toggleMenu(button){

    let currentMenu =
    button.nextElementSibling;

    // Close other opened menus
    document.querySelectorAll('.action-menu')
    .forEach(menu => {

        if(menu !== currentMenu){
            menu.style.display = 'none';
        }

    });

    // Toggle current menu
    if(currentMenu.style.display === 'flex'){
        currentMenu.style.display = 'none';
    }else{
        currentMenu.style.display = 'flex';
    }

}

// Close menu when clicking outside
document.addEventListener('click', function(e){

    if(
        !e.target.closest('.action-area')
    ){

        document.querySelectorAll('.action-menu')
        .forEach(menu => {
            menu.style.display = 'none';
        });

    }

});



</script>

</body>
</html>