<?php

require 'page_init.php';

if(!check_staff_login($conn)){
 header("Location:/home");
 die();
 
}

head('NPA Users',"$site | All Users","");

require 'menu.php';

// <!-- Message send report -->
 if(isset($_GET["msg_report"])){
 
   $msg = $_GET["msg_report"];
   $report = $_GET["report"];
   
   report_notice($report,$msg); 
   
  echo '<script src="scripts/report_notice.js"></script>';
     
 }
  
require './error_suc_msg.php';
require './custom_alert.php'; 
require './script_errors.php'; 


echo '<style>


</style>';


 $staff_id = $_SESSION["staff_id"];
 $staff_cat = $_SESSION["staff_cat"];
 $staff_det = collect_user_data($conn,"staffs","staff_id",$staff_id,"i");
$fullname = $staff_det["title"]." ".$staff_det["surname"]." ".$staff_det["othernames"];
$othernames = $staff_det["title"]." ".$staff_det["othernames"];

$staff_class = null_check($staff_det["class_handling"],null);


if(isset($_GET["query_string"])){
    
 
 
 
    
}
else{
   
if(isset($_POST["submit-filter-results"])){
$session = trim($_POST['session']);
 $term = trim($_POST["term"]);
$termSession = $term." ".$session;
$group = trim($_POST["group"]);
$viewClass = trim($_POST["class"]);




}
 else{
     
  
 //use $current session    
$current = get_current_session();
$session = $current['session'];
$term = $current["term"];
$termSession = $term." ".$session;
$group = "All";
$viewClass = "All";

 }
 
 if($staff_class){
  //check if this teacher's class is set
  if(check_exist4($conn,"class_set","staff_id","session","term","class",$staff_id,$session,$term,$staff_class,"isss")){
      
    echo 'staff class is set';  
      
  }
 else{
     
 // staff class not set, teachers must first set up their class.
 echo '<input type="hidden" id="staff_id" value="'.$staff_id.'">
   <input type="hidden" id="staff_name" value="'.$othernames.'">
   <input type="hidden" id="staff_class" value="'.$staff_class.'">
   <input type="hidden" id="term_session" value="'.$termSession.'">';
  
  require 'set_class.php';
  echo '<style>
  .footer{
     
    margin-top:100%;  
      }
     </style>';
  
  } 
 }
elseif(in_array($staff_cat,$authorized)){
   //only authorized staffs can view all results 
 require 'all_results.php';
 
}
else{
 //unknown permision   
 echo '<script>
 window.location ="/home?msg_report=Access denied !&report=failed";
 
 </script>'; 
 exit();
    
 }
}

  Addfooter($site);

?>



