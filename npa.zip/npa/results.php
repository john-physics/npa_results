<?php
 require 'page_init.php';
 
 head('Check Result',"$site | Check Result",""); //add header 
require 'menu.php';

// <!-- Message send report -->
 if(isset($_GET["msg_report"])){
 
   $msg = $_GET["msg_report"];
   $report = $_GET["report"];
   
   report_notice($report,$msg); 
   
  echo '<script src="scripts/report_notice.js"></script>';
     
 }
  
 require './error_suc_msg.php'; // detect and display error Messages if any
require './custom_alert.php'; 
require './script_errors.php'; 


echo '  <style>
     
        .result-card {
            max-width: 550px;
            width: 100%;
            margin:  auto;
            background: #ffffff;
            border-radius: 20px;
            box-shadow: 0 20px 35px -12px rgba(0, 0, 0, 0.12), 0 4px 12px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            transition: box-shadow 0.2s ease;
            position:relative;
            top:10px;
            margin-bottom:10px;
        }

 
        .card-inner {
            padding: 1.75rem 1.5rem 2rem 1.5rem;
        }

        /* academy branding */
        .academy-name {
            font-size: 1.9rem;
            font-weight: 700;
            letter-spacing: -0.3px;
            color: #0B2B4A;
            margin-bottom: 0.5rem;
            line-height: 1.2;
            border-left: 5px solid #D4AF37;
            padding-left: 1rem;
        }

        .address {
            font-size: 0.85rem;
            color: #4a5b6e;
            margin-bottom: 1.75rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid #e9edf2;
            line-height: 1.4;
        }

        /* form group styles — identical spacing and text */
        .form-group {
            margin-bottom: 1.4rem;
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #1F3A5F;
            margin-bottom: 0.45rem;
        }

        .form-group input,select {
            width: 100%;
            padding: 0.85rem 1rem;
            font-size: 1rem;
            font-family: inherit;
            background: #FFFFFF;
            border: 1.5px solid #e2e8f0;
            border-radius: 20px;
            transition: all 0.2s ease;
            color: #0A1C2F;
            font-weight: 500;
            outline: none;
        }

        .form-group input:focus {
            border-color: #D4AF37;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.2);
        }

    .form-group select:focus {
            border-color: #D4AF37;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.2);
        }

        .form-group input::placeholder {
            color: #9aaebf;
            font-weight: 400;
        }

  
        .view-btn {
            background: #0B2B4A;
            color: white;
            border: none;
            width: 100%;
            padding: 0.9rem 0;
            font-size: 1.05rem;
            font-weight: 600;
            font-family: inherit;
            border-radius: 40px;
            margin-top: 0.75rem;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 2px 6px rgba(11, 43, 74, 0.2);
            letter-spacing: 0.3px;
        }

        .view-btn:hover {
            background: #143e60;
            transform: scale(0.98);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .view-btn:active {
            transform: scale(0.97);
        }


.password-container {
    position: relative;
}

.password-container i {
    position: absolute;
    right: 15px;
    top: 70%;
    transform: translateY(-50%);
    cursor: pointer;
    color: #888;
}

.password-container i:hover {
    color: #333;
}

  
        .result-feedback {
            margin-top: 1.8rem;
            background: #F8FAFE;
            border-radius: 24px;
            padding: 1rem 1.2rem;
            border-left: 4px solid #D4AF37;
            font-size: 0.82rem;
            color: #1f3a5f;
            font-weight: 500;
            transition: all 0.2s;
            text-align: center;
            word-break: break-word;
        }

        .result-feedback i {
            font-style: normal;
            display: inline-block;
        }

        .error-message {
            color: #c0392b;
            background: #fff5f5;
            border-left-color: #c0392b;
        }

     
        @media (max-width: 480px) {
       
            .card-inner {
                padding: 1.5rem 1.2rem 1.8rem 1.2rem;
            }
            .academy-name {
                font-size: 1.7rem;
                padding-left: 0.8rem;
            }
            .view-btn {
                padding: 0.8rem 0;
                font-size: 1rem;
            }
        }

   
        @media (min-width: 768px) {
       
            .result-card {
                max-width: 700px;
                transition: none;
            }
            .card-inner {
                padding: 2rem 2rem 2.2rem 2rem;
            }
            .form-group label {
                font-size: 0.85rem;
            }
            .form-group input {
                padding: 0.9rem 1.1rem;
            }
        }

       .address i {
            font-style: normal;
        }

             
        button {
            background: #0B2B4A;
        }

        ::selection {
            background: #D4AF37;
            color: #0B2B4A;
        }
        
 
 
#spinner {
        display: none;
        border: 4px solid #f3f3f3;
        border-top: 4px solid #3498db;
        border-radius: 50%;
        width: 30px;
        height: 30px;
        animation: spin 0.5s linear infinite;
        margin: 10px auto;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
 
  #prep1{
     display:none;
     text-align:center;
     color:rgb(50,200,50);
     font-size:10px;
     position:relative;
     top:1px;
     font-weight:bold;
 }

#feed_back{
    
    display:block;
}
 
 #pin-error{
    display:block;
     position:absolute;
     top:80px;
     color:red;
     text-align:center;
     font-size:10px;
     font-style:italic;
     margin-left:10%;
 }
     
    </style>';

if($_SERVER["REQUEST_METHOD"]=="POST"){
    
 $pin = trim($_POST["std_pin"]);
 $class = trim($_POST["std_class"]);
 $term = trim($_POST["term"]);
 $session = trim($_POST["session"]);
 
 
 
 echo '<section class="section">
 
 <div id="resultDisplay" class="result-feedback">
   <span id="feed_back"><br>
   🔍 Reseults will display here
   <br><br>
   <b><i class="fa-solid fa-code"></i> Coding in progress...</b>
   </span>
   </div>
 
 </section>';
    

    
}
else{
    
 echo '<section class="section">
   <div class="result-card">
        <div class="card-inner">
            <div class="academy-name">'.$site2.'</div>
        <div class="address">'.$schoolAddress.'</div>

  <form id="resultForm" action="/results" method="post">
  <div class="form-group password-container">
     <label for="pin">PIN</label>
  <input type="password" id="pin" name="std_pin" placeholder="Enter your PIN" autocomplete="off">
         
 <i id="toggle-password" class="fas fa-eye"></i>
 <small id="pin-error"></small>
  </div>

   <div class="form-group">
    <label for="std_class">Class</label>
 <select name="std_class" id="std_class">';
                  
   $classes = sortClasses(collect_table_data1($conn,"variables","type","Class","s","","value"));
               
     foreach ($classes as $class){
                     
     echo '<option>'.$class.'</option>';    
      }
                 
   echo '</select></div>

 <div class="form-group">
   <label for="term">Exam</label>
<select name="term" id="term">';
  
   $terms = generate_terms();
foreach($terms as $term){

echo '<option value="'.$term.'">'.$term.' Examination</option>';
} 
 echo '</select></div>

     <div class="form-group">
     <label for="session">Year</label>
     <select id="session" name="session">';
  
   $sessions = generate_sessions();
  
foreach($sessions as $session){

echo '<option>'.$session.'</option>';

}
 
 echo '</select>
 </div>
  <button type="submit" id="viewResultsBtn" name="viewResultsBtn" value="view-my-result" class="view-btn">View Results</button>
      </form>


    <div id="resultDisplay" class="result-feedback">
   <span id="feed_back">🔍 Enter your PIN and tap "View Results"</span>
    <div id="spinner"></div>
   <small id="prep1">Fetching your results...</small>
            </div>
        </div>

    </div>
    </section>';   
    
}



Addfooter($site); 


?>


<script>
 
 const form = document.getElementById("resultForm"); 
form.addEventListener("submit", async (e) =>{
  
 const spinner =document.getElementById("spinner");
const prep1 =document.getElementById("prep1");
const feedBack =document.getElementById("feed_back");
 const pinError = document.getElementById("pin-error");
const pin = document.getElementById("pin").value.trim();
 
 e.preventDefault(); //prevent default submission initially
 
 if(!pin){
     
  pinError.innerHTML = "Please Enter your PIN";
  return;   
 }
  
 pinError.innerHTML = "";
 feedBack.style.display = "none";
 spinner.style.display ="flex";
 prep1.style.display ="block";

   // 2. AJAX PIN validation
 const formData = new URLSearchParams();
formData.append("std_pin", pin);
formData.append("submit_button_name", "check_pin");

  try {
    const res = await fetch("/includes/validatepin", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: formData
    });

    const data = await res.json();

    if (data.pin !== "valid") {
     
  pinError.innerHTML = data.message;
 feedBack.style.display = "block";
 spinner.style.display ="none";
 prep1.style.display ="none";

  return; // Stop submission
    }

    // Everything passed; submit normally
    form.submit(); // goes to PHP page via POST

  } catch (error) {
  
  pinError.innerHTML = "";
 feedBack.style.display = "block";
 spinner.style.display ="none";
 prep1.style.display ="none";
  
  showError(error,"Ajax Error");
    return;  //stop submission
   }  
 });
   
   
 
</script>


<script>
  
    // Toggle show/hide password
const togglePassword = document.getElementById("toggle-password");
const passwordField = document.getElementById("pin");

togglePassword.addEventListener("click", () => {
    if (passwordField.type === "password") {
        passwordField.type = "text";
        togglePassword.classList.remove("fa-eye");
        togglePassword.classList.add("fa-eye-slash");
    } else {
        passwordField.type = "password";
        togglePassword.classList.remove("fa-eye-slash");
        togglePassword.classList.add("fa-eye");
    }
});
</script>